Litterbug Lite - Forever v0.1.0-tc.1 (UNTESTED TEST CANDIDATE)

Ported from Litterbug Lite Classic v0.2.0-rc.4, actionbar edition.
This is a Forever-focused candidate using C_Container APIs and interface 16001
(archived reference; verify against live build). No game-client validation yet.

Behavior:
- Tracks ordinary bags and lists the five cheapest eligible stacks by TOTAL vendor value.
- Hearthstone, quest items, user-ignored items and items with missing safety/value data are excluded.
- Does NOT destroy, auto-delete, sell or auto-move items.
- A drag on a verified item tile calls the game's pickup function only; disposition is manual.
- /lbl compact, /lbl full, /lbl show, /lbl hide, /lbl reset, /lbl diag
- /lbl ignore [item link/id], /lbl ignore list, /lbl unignore [item link/id], /lbl ignore clear

Important test gates:
1. Addon loads without Lua errors; /lbl full draws HUD.
2. Inventory slot and free-slot counts for ordinary bags are correct; specialty bags excluded.
3. Quest items (including quest-flagged items) and Hearthstone NEVER appear.
4. Five lowest-total-value eligible stacks are correctly sorted.
5. HUD only picks up the exact same bag/slot stack after revalidation; no deletion.
6. SavedVariables and ignored item IDs persist after relog; Classic untouched.
7. An unavailable API or unresolved item cache causes exclusion, not unsafe action.

If any protected item appears, disable the addon and report a bug. Not approved as a stable release.
