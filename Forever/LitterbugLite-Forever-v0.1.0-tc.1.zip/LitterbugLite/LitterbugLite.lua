-- Litterbug Lite Forever 0.1.0-tc.1 (ported from Classic 0.2.0-rc.4)
-- Forever API candidate: requires actual client field testing.
-- Visual inventory-space reserve, not an item destruction addon.
-- Only explicit player drag from a verified virtual slot can pick up an item.
local module = CreateFrame("Frame")
local inventory = {candidates = {}, free = 0, total = 0, unknownBags = 0,
    protected = 0, pending = 0, scanned = false, revision = 0}
local ui = {buttons = {}, fullControls = {}, forcedVisible = false, status = ""}
local MIN_RESERVE, MAX_RESERVE, DEFAULT_RESERVE = 3, 5, 3
local HEARTHSTONE_ITEM_ID = 6948
local function IgnoredItems()
    LitterbugLiteForeverDB = LitterbugLiteForeverDB or {}
    LitterbugLiteForeverDB.ignoredItems = LitterbugLiteForeverDB.ignoredItems or {}
    return LitterbugLiteForeverDB.ignoredItems
end
local function Chat(message)
    if DEFAULT_CHAT_FRAME then DEFAULT_CHAT_FRAME:AddMessage("|cffb5d58e[Litterbug]|r " .. message) end
end
local function IsInteger(number)
    return type(number) == "number" and number == math.floor(number) and number >= 0
end
local function Slots(bagIndex)
    if C_Container and C_Container.GetContainerNumSlots then
        return C_Container.GetContainerNumSlots(bagIndex)
    end
end
local function FreeAndFamily(bagIndex)
    if C_Container and C_Container.GetContainerNumFreeSlots then
        return C_Container.GetContainerNumFreeSlots(bagIndex)
    end
end
local function ReadSlot(bagIndex, slotIndex)
    if C_Container and C_Container.GetContainerItemInfo then
        local data = C_Container.GetContainerItemInfo(bagIndex, slotIndex)
        if not data then return nil end
        return {id = data.itemID, link = data.hyperlink, count = data.stackCount,
            quality = data.quality, locked = data.isLocked,
            icon = data.iconFileID}
    end
end
local function QuestInformation(bagIndex, slotIndex)
    -- Modern container quest metadata: missing/invalid information is UNSAFE.
    local questInfoFunction = C_Container and C_Container.GetContainerItemQuestInfo
    if type(questInfoFunction) ~= "function" then return nil end
    local ok, info = pcall(questInfoFunction, bagIndex, slotIndex)
    if not ok or type(info) ~= "table" then return nil end
    if info.isQuestItem == true or (type(info.questID) == "number" and
        info.questID > 0) then return "PROTECTED" end
    if type(info.isQuestItem) ~= "boolean" then return nil end
    return "CLEAR"
end
local function BasicBag(bagIndex, family)
    -- Generic bags have family mask zero. Quivers (arrows), ammunition
    -- pouches (bullets), herb bags, etc. must never inflate ordinary space.
    if bagIndex == 0 then return family == nil or family == 0 end
    if type(family) == "number" then return family == 0 end
    -- Only use an API-confirmed generic-container class as a fallback.
    if type(ContainerIDToInventoryID) ~= "function" or
        type(GetInventoryItemLink) ~= "function" then return false end
    local itemLink = GetInventoryItemLink("player", ContainerIDToInventoryID(bagIndex))
    if not itemLink or type(GetItemInfoInstant) ~= "function" then return false end
    local _, _, _, _, _, classID, subClassID = GetItemInfoInstant(itemLink)
    return classID == 1 and subClassID == 0
end
local function CachedValue(itemIdentifier)
    if not IsInteger(itemIdentifier) or itemIdentifier == 0 then return nil end
    if type(GetItemInfo) ~= "function" then return nil end
    local name, _, quality, _, _, _, _, _, _, _, price, classID =
        GetItemInfo(itemIdentifier)
    if type(name) ~= "string" or quality == nil or not IsInteger(price) then
        return nil
    end
    if classID == nil and type(GetItemInfoInstant) == "function" then
        local _, _, _, _, _, instantClass = GetItemInfoInstant(itemIdentifier)
        classID = instantClass
    end
    if type(classID) ~= "number" then return nil end
    return name, price
end
local function Candidate(bagIndex, slotIndex)
    local item = ReadSlot(bagIndex, slotIndex)
    if not item then return nil end
    if not IsInteger(item.id) or item.id == 0 or type(item.link) ~= "string"
        or not IsInteger(item.count) or item.count == 0 or
        item.quality == nil or item.locked ~= false then
        return nil, "UNSAFE"
    end
    if item.id == HEARTHSTONE_ITEM_ID or IgnoredItems()[item.id] then
        return nil, "PROTECTED"
    end
    if QuestInformation(bagIndex, slotIndex) ~= "CLEAR" then
        return nil, "QUEST_UNKNOWN"
    end
    -- Only item metadata observed in the client is eligible for valuation.
    local name, unitPrice = CachedValue(item.id)
    if not name then return nil, "METADATA" end
    local totalValue = unitPrice * item.count
    if not IsInteger(totalValue) then return nil, "PRICE" end
    return {bag = bagIndex, slot = slotIndex, id = item.id,
        link = item.link, count = item.count, icon = item.icon,
        name = name, unitPrice = unitPrice, value = totalValue}
end
local function CopperText(value)
    local gold = math.floor(value / 10000)
    local silver = math.floor((value % 10000) / 100)
    local copper = value % 100
    if gold > 0 then return gold .. "g " .. silver .. "s " .. copper .. "c" end
    if silver > 0 then return silver .. "s " .. copper .. "c" end
    return copper .. "c"
end
local function Scan()
    local snapshot = {candidates = {}, free = 0, total = 0, unknownBags = 0,
        protected = 0, pending = 0, scanned = true,
        revision = inventory.revision + 1}
    for bagIndex = 0, (NUM_BAG_SLOTS or 4) do
        local freeSlots, family = FreeAndFamily(bagIndex)
        local slots = Slots(bagIndex)
        if IsInteger(slots) and IsInteger(freeSlots) and
            BasicBag(bagIndex, family) then
            snapshot.total = snapshot.total + slots
            snapshot.free = snapshot.free + freeSlots
            for slotIndex = 1, slots do
                local candidate, reason = Candidate(bagIndex, slotIndex)
                if candidate then
                    snapshot.candidates[#snapshot.candidates + 1] = candidate
                elseif reason == "QUEST_UNKNOWN" or reason == "PROTECTED" then
                    snapshot.protected = snapshot.protected + 1
                elseif reason then
                    snapshot.pending = snapshot.pending + 1
                end
            end
        elseif not IsInteger(slots) or not IsInteger(freeSlots) then
            snapshot.unknownBags = snapshot.unknownBags + 1
        end
    end
    table.sort(snapshot.candidates, function(first, second)
        if first.value ~= second.value then return first.value < second.value end
        if first.bag ~= second.bag then return first.bag < second.bag end
        return first.slot < second.slot
    end)
    inventory = snapshot
end
local function UpdateStatus(message)
    ui.status = message
    if ui.statusLabel then ui.statusLabel:SetText(message) end
end
local function SaveGeometry()
    if not ui.frame or type(LitterbugLiteForeverDB) ~= "table" then return end
    LitterbugLiteForeverDB.hudLeft = ui.frame:GetLeft()
    LitterbugLiteForeverDB.hudBottom = ui.frame:GetBottom()
end
local function ReadReserve()
    local value = type(LitterbugLiteForeverDB) == "table" and LitterbugLiteForeverDB.reserveSlots
    if not IsInteger(value) then return DEFAULT_RESERVE end
    return math.max(MIN_RESERVE, math.min(MAX_RESERVE, value))
end
local function ReadOnlyRow(candidate, button)
    button.candidate = candidate
    if not candidate then
        button:Hide()
        return
    end
    button:Show()
    button.icon:SetTexture(candidate.icon or "Interface\\Icons\\INV_Misc_QuestionMark")
    button.count:SetText(candidate.count > 1 and candidate.count or "")
    button.value:SetText(CopperText(candidate.value))
end
local function OnMouseDrag(button)
    local candidate = button.candidate
    if not candidate or (InCombatLockdown and InCombatLockdown()) then
        UpdateStatus("Cannot pick up that item right now")
        return
    end
    if type(GetCursorInfo) ~= "function" or GetCursorInfo() ~= nil then
        UpdateStatus("Cursor occupied: return its contents first")
        return
    end
    local current = Candidate(candidate.bag, candidate.slot)
    if not current or current.id ~= candidate.id or
        current.link ~= candidate.link or current.count ~= candidate.count or
        current.value ~= candidate.value then
        UpdateStatus("Inventory changed; rescan first")
        Scan()
        if ui.refresh then ui.refresh() end
        return
    end
    local pickup = C_Container and C_Container.PickupContainerItem
    if type(pickup) ~= "function" then
        UpdateStatus("Bag pickup API unavailable")
        return
    end
    local success = pcall(pickup, candidate.bag, candidate.slot)
    if success then
        UpdateStatus("Item picked up; drop it using WoW's inventory UI")
    else
        UpdateStatus("Item pickup blocked by game client")
    end
end
local function CreateItemButton(parent, index)
    local button = CreateFrame("Button", nil, parent)
    button:SetSize(46, 46)
    button:SetPoint("TOPRIGHT", parent, "TOPRIGHT", -10 - (MAX_RESERVE-index)*54, -77)
    local background = button:CreateTexture(nil, "BACKGROUND")
    background:SetAllPoints(button)
    background:SetTexture("Interface\\Buttons\\UI-Quickslot2")
    button.icon = button:CreateTexture(nil, "ARTWORK")
    button.icon:SetPoint("TOPLEFT", 5, -5)
    button.icon:SetPoint("BOTTOMRIGHT", -5, 5)
    button.count = button:CreateFontString(nil, "OVERLAY", "NumberFontNormal")
    button.count:SetPoint("BOTTOMRIGHT", button, "BOTTOMRIGHT", -5, 5)
    button.value = button:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    button.value:SetPoint("TOP", button, "BOTTOM", 0, -1)
    button:RegisterForDrag("LeftButton")
    button:SetScript("OnDragStart", OnMouseDrag)
    button:SetScript("OnEnter", function(self)
        if self.candidate and GameTooltip then
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            GameTooltip:SetBagItem(self.candidate.bag, self.candidate.slot)
            GameTooltip:AddLine("Total vendor value: " ..
                CopperText(self.candidate.value), 1, 0.82, 0.25)
            GameTooltip:Show()
        end
    end)
    button:SetScript("OnLeave", function()
        if GameTooltip then GameTooltip:Hide() end
    end)
    button:Hide()
    return button
end
local function Refresh()
    if not ui.frame then return end
    local reserve = ReadReserve()
    ui.reserveValue:SetText("Reserve " .. reserve)
    ui.bagLabel:SetText("Ordinary bag slots: " .. inventory.free .. "/" ..
        inventory.total)
    local needed = math.max(0, reserve - inventory.free)
    -- Always present the five lowest-value eligible occupied stacks.
    -- Reserve controls when the HUD appears automatically, not queue size.
    local displayCount = math.min(#inventory.candidates, MAX_RESERVE)
    -- All virtual cells retain their physical x positions: cheapest on left
    -- among the displayed entries, with empty slots remaining to the left.
    for index, button in ipairs(ui.buttons) do
        local first = MAX_RESERVE - displayCount + 1
        local candidateIndex = index - first + 1
        ReadOnlyRow(candidateIndex > 0 and
            candidateIndex <= displayCount and inventory.candidates[candidateIndex]
            or nil, button)
    end
    local fullAndNoTrash = inventory.free == 0 and
        #inventory.candidates == 0 and inventory.unknownBags == 0
    if fullAndNoTrash then
        ui.statusLabel:SetTextColor(1, 0.22, 0.22)
        UpdateStatus("BAGS FULL. NO VERIFIED DISCARD CANDIDATES.")
    elseif inventory.unknownBags > 0 then
        ui.statusLabel:SetTextColor(1, 0.55, 0.25)
        UpdateStatus("Bag capacity unavailable; check inventory")
    else
        ui.statusLabel:SetTextColor(1, 0.82, 0.35)
        UpdateStatus(ui.status ~= "" and ui.status or
            (#inventory.candidates .. " eligible stacks ranked by total vendor value"))
    end
    local show = ui.forcedVisible or fullAndNoTrash or
        (needed > 0 and displayCount > 0)
    if show then ui.frame:Show() else ui.frame:Hide() end
end
local function Button(parent, text, x, y, width, callback)
    local button = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
    button:SetSize(width, 22)
    button:SetPoint("TOPLEFT", parent, "TOPLEFT", x, y)
    button:SetText(text)
    button:SetScript("OnClick", callback)
    return button
end
-- Compact tray: five touching 46px cells, with an 8px draggable outer frame.
-- Item icons retain their normal drag-to-pickup behavior; the empty frame
-- border is the handle for moving the entire HUD.
local function ApplyLayout()
    if not ui.frame then return end
    local compact = LitterbugLiteForeverDB and LitterbugLiteForeverDB.compactMode == true
    ui.frame:SetSize(compact and 246 or 294, compact and 62 or 166)
    if ui.compactShade then
        if compact then ui.compactShade:Show() else ui.compactShade:Hide() end
    end
    ui.frame:SetBackdropColor(compact and 0.025 or 0.04, compact and 0.03 or 0.06, compact and 0.035 or 0.045, compact and 0.90 or 0.94)
    ui.frame:SetBackdropBorderColor(compact and 0.37 or 0.58, compact and 0.37 or 0.54, compact and 0.39 or 0.37, 1)
    for _, control in ipairs(ui.fullControls) do
        if compact then control:Hide() else control:Show() end
    end
    for index, button in ipairs(ui.buttons) do
        button:ClearAllPoints()
        if compact then
            button:SetPoint("TOPLEFT", ui.frame, "TOPLEFT", 8 + (index - 1) * 46, -8)
            button.value:Hide()
        else
            button:SetPoint("TOPRIGHT", ui.frame, "TOPRIGHT", -10 - (MAX_RESERVE-index)*54, -77)
            button.value:Show()
        end
    end
end
local function SetCompact(enabled)
    LitterbugLiteForeverDB.compactMode = enabled and true or false
    ApplyLayout()
    SaveGeometry()
    ui.forcedVisible = true
    ui.status = ""
    Scan()
    Refresh()
    Chat(enabled and "Action-bar compact view. Drag the outer border to move. /lbl full restores the window." or
        "Full view restored. /lbl compact returns to the five-slot strip.")
end
local function CreateUI()
    local frame = CreateFrame("Frame", "LitterbugLiteHUD", UIParent, "BackdropTemplate")
    frame:SetSize(294, 166)
    frame:SetClampedToScreen(true)
    frame:SetFrameStrata("MEDIUM")
    frame:SetMovable(true)
    frame:EnableMouse(true)
    frame:SetBackdrop({bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", edgeSize = 12,
        insets = {left=3,right=3,top=3,bottom=3}})
    frame:SetBackdropColor(0.04,0.06,0.045,0.94)
    frame:SetBackdropBorderColor(0.58,0.54,0.37,1)
    -- Action-bar-style recessed tray; the border remains a drag handle.
    local compactShade = frame:CreateTexture(nil, "BACKGROUND", nil, 1)
    compactShade:SetPoint("TOPLEFT", frame, "TOPLEFT", 5, -5)
    compactShade:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -5, 5)
    compactShade:SetColorTexture(0.015, 0.02, 0.025, 0.90)
    compactShade:Hide()
    ui.compactShade = compactShade
    if type(LitterbugLiteForeverDB.hudLeft) == "number" and
        type(LitterbugLiteForeverDB.hudBottom) == "number" then
        frame:SetPoint("BOTTOMLEFT", UIParent, "BOTTOMLEFT",
            LitterbugLiteForeverDB.hudLeft, LitterbugLiteForeverDB.hudBottom)
    else
        frame:SetPoint("CENTER", UIParent, "CENTER", 0, -130)
    end
    frame:RegisterForDrag("LeftButton")
    frame:SetScript("OnDragStart", frame.StartMoving)
    frame:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        SaveGeometry()
    end)
    ui.frame = frame
    local title = frame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    title:SetPoint("TOPLEFT", frame, "TOPLEFT", 10, -9)
    title:SetText("Litterbug Lite")
    ui.fullControls[#ui.fullControls+1] = title
    local close = CreateFrame("Button", nil, frame, "UIPanelCloseButton")
    close:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -2, -2)
    ui.fullControls[#ui.fullControls+1] = close
    close:SetScript("OnClick", function()
        ui.forcedVisible = false
        frame:Hide()
    end)
    ui.bagLabel = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    ui.bagLabel:SetPoint("TOPLEFT", frame, "TOPLEFT", 10, -30)
    ui.reserveValue = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    ui.reserveValue:SetPoint("TOPLEFT", frame, "TOPLEFT", 164, -30)
    ui.fullControls[#ui.fullControls+1] = ui.bagLabel
    ui.fullControls[#ui.fullControls+1] = ui.reserveValue
    local function AdjustReserve(change)
        LitterbugLiteForeverDB.reserveSlots = math.max(MIN_RESERVE,
            math.min(MAX_RESERVE, ReadReserve() + change))
        ui.status = ""
        Refresh()
    end
    local minus = Button(frame, "-", 238, -26, 20, function() AdjustReserve(-1) end)
    local plus = Button(frame, "+", 262, -26, 20, function() AdjustReserve(1) end)
    ui.fullControls[#ui.fullControls+1] = minus
    ui.fullControls[#ui.fullControls+1] = plus
    for index = 1, MAX_RESERVE do
        ui.buttons[index] = CreateItemButton(frame, index)
    end
    ui.statusLabel = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    ui.statusLabel:SetPoint("TOPLEFT", frame, "TOPLEFT", 10, -52)
    ui.statusLabel:SetWidth(272)
    ui.statusLabel:SetJustifyH("LEFT")
    ui.fullControls[#ui.fullControls+1] = ui.statusLabel
    local refreshButton = Button(frame, "Refresh", 43, -139, 88, function()
        ui.status = ""
        Scan()
        Refresh()
    end)
    local hideButton = Button(frame, "Hide", 161, -139, 88, function()
        ui.forcedVisible = false
        frame:Hide()
    end)
    ui.fullControls[#ui.fullControls+1] = refreshButton
    ui.fullControls[#ui.fullControls+1] = hideButton
    ui.refresh = Refresh
    ApplyLayout()
end
local function ParseItemIDs(text)
    local ids, seen = {}, {}
    for rawID in text:gmatch("|Hitem:(%d+)") do
        local id = tonumber(rawID)
        if id and not seen[id] then ids[#ids+1] = id; seen[id] = true end
    end
    if #ids == 0 then
        local rawID = text:match("^%s*(%d+)%s*$")
        if rawID then ids[1] = tonumber(rawID) end
    end
    return ids
end

local function HandleIgnore(operation, arguments)
    local ignored = IgnoredItems()
    if operation == "list" then
        local ids = {}
        for id, enabled in pairs(ignored) do
            if enabled then ids[#ids+1] = tonumber(id) end
        end
        table.sort(ids)
        if #ids == 0 then Chat("Ignore list is empty.") end
        for _, id in ipairs(ids) do
            local link = type(GetItemInfo) == "function" and select(2, GetItemInfo(id))
            Chat((link or ("Item ID " .. id)) .. " (" .. id .. ")")
        end
        return
    elseif operation == "clear" then
        LitterbugLiteForeverDB.ignoredItems = {}
        Chat("Ignore list cleared. Permanent exclusions remain active.")
    elseif operation == "add" or operation == "remove" then
        local ids = ParseItemIDs(arguments or "")
        if #ids == 0 then
            Chat("Use Shift-clicked item links or a numeric item ID.")
            return
        end
        for _, id in ipairs(ids) do
            if operation == "add" then ignored[id] = true else ignored[id] = nil end
        end
        Chat((operation == "add" and "Ignored " or "Unignored ") .. #ids .. " item(s).")
    else
        Chat("Commands: /lbl ignore [items] | /lbl ignore list | /lbl unignore [items] | /lbl ignore clear")
        return
    end
    ui.status = ""
    Scan()
    Refresh()
end

SLASH_LITTERBUGLITE1 = "/lbl"
SLASH_LITTERBUGLITE2 = "/litterbug"
SlashCmdList.LITTERBUGLITE = function(argument)
    argument = string.match(argument or "", "^%s*(.-)%s*$")
    local command, remainder = argument:match("^(%S+)%s*(.-)$")
    local lowercaseCommand = command and command:lower() or ""
    if lowercaseCommand == "compact" then
        return SetCompact(true)
    elseif lowercaseCommand == "full" then
        return SetCompact(false)
    elseif lowercaseCommand == "ignore" then
        if remainder:lower() == "list" then return HandleIgnore("list") end
        if remainder:lower() == "clear" then return HandleIgnore("clear") end
        if remainder == "" then return HandleIgnore("help") end
        return HandleIgnore("add", remainder)
    elseif lowercaseCommand == "unignore" then
        return HandleIgnore("remove", remainder)
    end
    argument = argument:lower()
    if argument == "diag" then
        if DEFAULT_CHAT_FRAME then
            DEFAULT_CHAT_FRAME:AddMessage("Litterbug Lite Forever v0.1.0-tc.1: normal " ..
                inventory.free .. "/" .. inventory.total .. ", excluded bags not counted," ..
                " candidates " .. #inventory.candidates ..
                ", protected/unknown " .. inventory.protected .. "/" ..
                inventory.pending .. ", bag unknown " .. inventory.unknownBags)
        end
        return
    elseif argument == "reset" then
        ui.frame:ClearAllPoints()
        ui.frame:SetPoint("CENTER", UIParent, "CENTER", 0, -130)
        SaveGeometry()
        ui.forcedVisible = true
    elseif argument == "show" then
        ui.forcedVisible = true
    elseif argument == "hide" then
        ui.forcedVisible = false
        ui.frame:Hide()
        return
    else
        ui.forcedVisible = not ui.forcedVisible
    end
    ui.status = ""
    Scan()
    Refresh()
end
module:RegisterEvent("ADDON_LOADED")
module:RegisterEvent("BAG_UPDATE_DELAYED")
module:RegisterEvent("GET_ITEM_INFO_RECEIVED")
module:SetScript("OnEvent", function(_, event, loaded)
    if event == "ADDON_LOADED" and loaded == "LitterbugLite" then
        LitterbugLiteForeverDB = LitterbugLiteForeverDB or {}
        LitterbugLiteForeverDB.reserveSlots = ReadReserve()
        CreateUI()
        Scan()
        Refresh()
    elseif (event == "BAG_UPDATE_DELAYED" or event == "GET_ITEM_INFO_RECEIVED") and ui.frame then
        ui.status = ""
        Scan()
        Refresh()
    end
end)
