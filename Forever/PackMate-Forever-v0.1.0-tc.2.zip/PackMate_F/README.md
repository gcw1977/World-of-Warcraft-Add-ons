# PackMate — Forever 0.1.0-tc.1

UNTESTED TEST CANDIDATE built from the owner's PackMate Classic 0.3.1 package.
The account-wide saved-variable name and UI frame names are isolated from Classic.
This is a direct test port, NOT a replacement for the existing modular Forever
construction branch `construction/PackMate_F/0.1.0-dev.1` and does not supersede it.

## Features
- Three-line draggable/resizable XP, loyalty, unused-points HUD for Hunter pets.
- Happiness mood colors and sassy/stoic/mute notices.
- Reports pet XP gained based on observed per-session XP changes.
- Stores per-pet observed XP totals; no cross-session inferred deltas.
- Commands: `/pm show`, `hide`, `reset`, `status`, `sassy`, `stoic`, `mute`, `xp on`, `xp off`.

## Forever adapters and unresolved gates
- C_PetInfo preferred for happiness, loyalty, training-points; legacy fallbacks guarded.
- Hunter class gating; no pet / missing GUID => no persistent ledger writes.
- Missing XP, loyalty, training APIs display unavailable, not fictitious zero.
- Optional events guarded; PET_HAPPINESS_UPDATE deliberately not registered.
- Interface 16001 is a **beta snapshot** and must be compared with live build.
- Actual Forever pet APIs, return shapes, UI, slash commands, XP events, and
  SavedVariables persistence have NOT been tested in-game.
- If the modern client distinguishes pet talents from training points,
  the exact meaning of C_PetInfo.GetPetTrainingPoints needs an in-game check.

## Test sequence
1. Install only in Forever, confirm loading, `/pm status` and `/pm show`.
2. Summon Hunter pet; no pet and non-Hunter character should hide HUD.
3. Earn pet XP, level the pet, and check duplicate/false XP increments.
4. Change happiness and wait 30s/60s for escalation; check mode toggles.
5. Compare loyalty and training points with pet UI; unavailable should not say 0.
6. Move/resize HUD and relog; verify persistence and separate Classic settings.

No release promotion authorized. No game-client validation performed.


## tc.2 observations and remaining limits
- XP credits only consecutive valid readings of the same active pet GUID, including a single level-up transition. No inferred multiple-level gaps.
- Pet swaps, reloads and missing/secret XP readings reset the arithmetic baseline. No XP is credited for unseen intervals.
- Saved variables keep the observed totals by session GUID, but Forever GUID obfuscation means those records are NOT a reliable lifetime identity across sessions.
- Type and value checks on pet identity are guarded; unavailable values suppress accounting rather than fabricating XP.
- This build has not been tested in the Forever live client. Commands, UI, loyalty, happiness, and pet XP require owner testing.
