local addonFrame = CreateFrame("Frame", "PackMateForeverEventFrame")
local petDisplay = CreateFrame("Frame", "PackMateForeverDisplay", UIParent, "BackdropTemplate")
petDisplay:SetSize(165, 49)
petDisplay:SetResizable(true)
-- Modern Classic clients replaced SetMinResize/SetMaxResize with SetResizeBounds.
if petDisplay.SetResizeBounds then
 petDisplay:SetResizeBounds(145, 48, 280, 90)
elseif petDisplay.SetMinResize and petDisplay.SetMaxResize then
 petDisplay:SetMinResize(145, 48)
 petDisplay:SetMaxResize(280, 90)
end
petDisplay:SetFrameStrata("MEDIUM")
petDisplay:SetPoint("CENTER", UIParent, "CENTER", 0, -155)
petDisplay:SetMovable(true)
petDisplay:EnableMouse(true)
petDisplay:RegisterForDrag("LeftButton")
petDisplay:SetClampedToScreen(true)
petDisplay:Hide()
petDisplay:SetBackdrop({bgFile="Interface\\Tooltips\\UI-Tooltip-Background",edgeFile="Interface\\Tooltips\\UI-Tooltip-Border",tile=true,tileSize=16,edgeSize=14,insets={left=3,right=3,top=3,bottom=3}})
petDisplay:SetBackdropColor(0,0,0,0.35)
petDisplay:SetBackdropBorderColor(0.4,0.4,0.4,0.45)
petDisplay:SetScript("OnDragStart", function(self) self:StartMoving() end)
petDisplay:SetScript("OnDragStop", function(self)
 self:StopMovingOrSizing()
 local anchor, _, relativeAnchor, horizontalOffset, verticalOffset = self:GetPoint()
 PackMateForeverDatabase.position = {anchor=anchor, relativeAnchor=relativeAnchor, x=horizontalOffset, y=verticalOffset}
end)
-- Grip matches GatherLedger's Shopping List HUD. Drag the background to move,
-- drag the lower-right corner to resize. Save dimensions on mouse release.
local resizeGrip = CreateFrame("Button", nil, petDisplay)
resizeGrip:SetSize(17, 17)
resizeGrip:SetPoint("BOTTOMRIGHT", petDisplay, "BOTTOMRIGHT", 0, 0)
resizeGrip:SetFrameLevel(petDisplay:GetFrameLevel() + 2)
local resizeIcon = resizeGrip:CreateTexture(nil, "OVERLAY")
resizeIcon:SetAllPoints()
resizeIcon:SetTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Up")
resizeGrip:SetNormalTexture(resizeIcon)
resizeGrip:SetScript("OnMouseDown", function(_, mouseButton)
 if mouseButton == "LeftButton" then petDisplay:StartSizing("BOTTOMRIGHT") end
end)
resizeGrip:SetScript("OnMouseUp", function(_, mouseButton)
 if mouseButton ~= "LeftButton" then return end
 petDisplay:StopMovingOrSizing()
 if PackMateForeverDatabase then
  PackMateForeverDatabase.size = {width=petDisplay:GetWidth(), height=petDisplay:GetHeight()}
 end
end)
-- Forever port from Classic PackMate v0.3.1. Three compact text rows.
-- Companion provenance: user-owned Beestwood Industries Classic package.
-- No third-party code included.
-- All Forever API compatibility untested in live client.
-- Three compact text rows; no name or progress bar.
local experienceText = petDisplay:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
experienceText:SetPoint("TOPLEFT", petDisplay, "TOPLEFT", 7, -6)
experienceText:SetJustifyH("LEFT")

local loyaltyText = petDisplay:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
loyaltyText:SetPoint("TOPLEFT", experienceText, "BOTTOMLEFT", 0, -2)
loyaltyText:SetJustifyH("LEFT")

local trainingText = petDisplay:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
trainingText:SetPoint("TOPLEFT", loyaltyText, "BOTTOMLEFT", 0, -2)
trainingText:SetJustifyH("LEFT")

local function announce(message)
 DEFAULT_CHAT_FRAME:AddMessage("|cff76c9ee[PM]|r "..message)
end
-- Happiness controls reuse the existing three HUD lines; no fourth indicator.
local happinessNames = {[1]="UNHAPPY", [2]="CONTENT", [3]="HAPPY"}
local happinessColors = {
 [1]={1.00,0.24,0.24}, [2]={1.00,0.88,0.15}, [3]={0.25,1.00,0.32}
}
local activeHappinessPetGUID = nil
local lastObservedHappiness = nil
local happinessChangedAt = nil
local deliveredReminderStages = {}

local function resetHappinessTracking()
 activeHappinessPetGUID = nil
 lastObservedHappiness = nil
 happinessChangedAt = nil
 deliveredReminderStages = {}
end

local function showHappinessMessage(message, repeatCount)
 if not PackMateForeverDatabase or PackMateForeverDatabase.happinessMode == "mute" then return end
 for messageIndex=1,(repeatCount or 1) do announce(message) end
end

local function announceHappinessChange(petName, happiness)
 if PackMateForeverDatabase.happinessMode == "mute" then return end
 if PackMateForeverDatabase.happinessMode == "stoic" then
  showHappinessMessage(string.format("%s STATUS CHANGED TO %s", petName:upper(), happinessNames[happiness]))
 elseif happiness == 2 then
  showHappinessMessage(petName .. " is less than thrilled to be on this adventure. Perhaps a little snack is in order?", 3)
 elseif happiness == 1 then
  showHappinessMessage(petName:upper() .. " IS APPALLED! " .. petName:upper() .. " DEMANDS MULTIPLE SNACKS...and maybe chin scritches.", 3)
 elseif happiness == 3 then
  showHappinessMessage(petName .. " has forgiven you, you always give the BEST treats.")
 end
end

-- Capability adapter: returned values are evidence, not defaults. If an API is absent or
-- restricted, return nil and display 'unavailable' rather than inventing zeroes.
local function safePetCall(apiFunction)
 if type(apiFunction) ~= "function" then return nil end
 local didSucceed, first, second = pcall(apiFunction)
 if not didSucceed then return nil end
 return first, second
end

local function safeNonnegative(value)
 local didSucceed, number = pcall(tonumber, value)
 if didSucceed and type(number) == "number" and number >= 0 and number < math.huge then
  return number
 end
 return nil
end

local function getLoyaltyLabel()
 local namespaced = C_PetInfo and C_PetInfo.GetPetLoyalty
 local value = safePetCall(namespaced)
 if value == nil then value = safePetCall(GetPetLoyalty) end
 if type(value) == "string" and value ~= "" then return value end
 return nil
end

local function getTrainingAvailable()
 local namespaced = C_PetInfo and C_PetInfo.GetPetTrainingPoints
 local total, spent = safePetCall(namespaced)
 if total == nil then total, spent = safePetCall(GetPetTrainingPoints) end
 total, spent = safeNonnegative(total), safeNonnegative(spent)
 if not total or not spent or spent > total then return nil end
 return total-spent
end

local function getExperience()
 local current, needed = safePetCall(GetPetExperience)
 current, needed = safeNonnegative(current), safeNonnegative(needed)
 if not current or not needed or needed <= 0 or current > needed then return nil,nil end
 return current, needed
end

-- GUIDs are stable only within the active client session. Persisted records are
-- best-effort observations, not proof of a lifetime pet identity across logins.
-- A discontinuity (pet change, missing XP, reload) always starts a fresh XP baseline.
local activeExperienceSample = nil
local sessionPetGUIDs = {}

local function updateHappiness(petGUID, petName)
 if not petGUID then
  resetHappinessTracking()
  return
 end
 local namespacedHappiness = C_PetInfo and C_PetInfo.GetPetHappiness
 local happiness = safePetCall(namespacedHappiness)
 if happiness == nil then happiness = safePetCall(GetPetHappiness) end
 happiness = safeNonnegative(happiness)
 local happinessColor = happinessColors[happiness]
 if happinessColor then
  experienceText:SetTextColor(unpack(happinessColor))
  loyaltyText:SetTextColor(unpack(happinessColor))
  trainingText:SetTextColor(unpack(happinessColor))
 else
  experienceText:SetTextColor(1,1,1)
  loyaltyText:SetTextColor(1,1,1)
  trainingText:SetTextColor(1,1,1)
 end
 if not happinessNames[happiness] then
  resetHappinessTracking()
  return
 end
 if activeHappinessPetGUID ~= petGUID then
  -- First observation establishes the baseline. Never invent an earlier mood change.
  activeHappinessPetGUID = petGUID
  lastObservedHappiness = happiness
  happinessChangedAt = GetTime()
  deliveredReminderStages = {}
  return
 end
 if happiness ~= lastObservedHappiness then
  lastObservedHappiness = happiness
  happinessChangedAt = GetTime()
  deliveredReminderStages = {}
  announceHappinessChange(petName, happiness)
  return
 end
 if PackMateForeverDatabase.happinessMode ~= "sassy" or not happinessChangedAt then return end
 local secondsSinceChange = GetTime() - happinessChangedAt
 if happiness == 2 then
  for reminderStage, reminderSeconds in ipairs({30,60}) do
   if secondsSinceChange >= reminderSeconds and not deliveredReminderStages[reminderStage] then
    deliveredReminderStages[reminderStage] = true
    showHappinessMessage(petName .. " is less than thrilled to be on this adventure. Perhaps a little snack is in order?", 3)
   end
  end
 elseif happiness == 1 then
  if secondsSinceChange >= 60 and not deliveredReminderStages[1] then
   deliveredReminderStages[1] = true
   showHappinessMessage(petName:upper() .. " STOMPS FOOT PETULANTLY")
  end
  if secondsSinceChange >= 180 and not deliveredReminderStages[2] then
   deliveredReminderStages[2] = true
   showHappinessMessage(petName .. " is beginning to think you don't love and respect them anymore.")
  end
 end
end

local function currentPetIdentity()
 -- Keep the entire identity inspection inside pcall. Forever can expose restricted
 -- values: pcall(UnitGUID, ...) alone doesn't make comparisons on its result safe.
 local okay, guid, name, level = pcall(function()
  local _, classToken = UnitClass("player")
  if classToken ~= "HUNTER" or not UnitExists("pet") then return nil end
  if type(HasPetUI) == "function" then
   local _, isHunterPet = HasPetUI()
   if isHunterPet == false then return nil end
  end
  local petGUID = UnitGUID("pet")
  if type(petGUID) ~= "string" or petGUID == "" then return nil end
  local petName = UnitName("pet")
  if type(petName) ~= "string" or petName == "" then petName = "Pet" end
  local petLevel = UnitLevel("pet")
  if type(petLevel) ~= "number" or petLevel < 1 or petLevel >= math.huge then return nil end
  return petGUID, petName, petLevel
 end)
 if not okay then return nil end
 return guid, name, level
end

local function updatePetInformation()
 if not PackMateForeverDatabase or type(PackMateForeverDatabase.pets) ~= "table" then return end
 local petGUID, petName, petLevel = currentPetIdentity()
 if not petGUID then
  activeExperienceSample = nil
  petDisplay:Hide()
  updateHappiness(nil, nil)
  return
 end

 local petRecord = PackMateForeverDatabase.pets[petGUID]
 if type(petRecord) ~= "table" then
  petRecord = {name = petName, level = petLevel, totalObservedExperience = 0}
 end
 if not sessionPetGUIDs[petGUID] then
  -- Never trust the previous session's level or XP baseline for arithmetic.
  sessionPetGUIDs[petGUID] = true
  petRecord.totalObservedExperience = safeNonnegative(petRecord.totalObservedExperience) or 0
 end
 local currentExperience, requiredExperience = getExperience()
 local oldSample = activeExperienceSample
 local samePet = oldSample and oldSample.guid == petGUID
 local gained = nil
 local leveled = false

 if samePet and currentExperience and requiredExperience then
  if petLevel == oldSample.level then
   if currentExperience >= oldSample.experience then
    gained = currentExperience - oldSample.experience
   end
  elseif petLevel == oldSample.level + 1 then
   -- One observed level-up: no double credit for the XP carried into the next level.
   -- A larger gap cannot be reconstructed from the available observations.
   gained = oldSample.required - oldSample.experience + currentExperience
   leveled = gained >= 0
  end
 end

 -- Do not bridge any missing or invalid sample; also do not bridge pet swaps.
 if currentExperience and requiredExperience then
  activeExperienceSample = {
   guid = petGUID, level = petLevel,
   experience = currentExperience, required = requiredExperience,
  }
 else
  activeExperienceSample = nil
 end

 if gained and gained > 0 then
  petRecord.totalObservedExperience = (petRecord.totalObservedExperience or 0) + gained
  if PackMateForeverDatabase.announceExperience ~= false and PackMateForeverDatabase.happinessMode ~= "mute" then
   announce(string.format("%s received %d observed XP (%d/%d)", petName, gained, currentExperience, requiredExperience))
  end
 end
 if leveled and PackMateForeverDatabase.happinessMode ~= "mute" then
  announce(string.format("%s reached level %d!", petName, petLevel))
 end

 petRecord.name = petName
 petRecord.level = petLevel
 petRecord.lastExperience = currentExperience -- informational only, never used after login
 petRecord.lastRequiredExperience = requiredExperience
 local loyalty = getLoyaltyLabel()
 local freeTrainingPoints = getTrainingAvailable()
 petRecord.loyalty = loyalty
 petRecord.availableTrainingPoints = freeTrainingPoints
 PackMateForeverDatabase.pets[petGUID] = petRecord
 if leveled and freeTrainingPoints and freeTrainingPoints > 0 and PackMateForeverDatabase.happinessMode ~= "mute" then
  announce(string.format("%s has %d unused training points. Check Beast Training for skills you can teach.", petName, freeTrainingPoints))
 end

 if currentExperience and requiredExperience then
  experienceText:SetText(string.format("XP: %d/%d - %.1f%%", currentExperience, requiredExperience, currentExperience * 100 / requiredExperience))
 else
  experienceText:SetText("XP: unavailable")
 end
 loyaltyText:SetText("Loyalty: " .. tostring(loyalty or "N/A"))
 if freeTrainingPoints then
  trainingText:SetText(string.format("Unused TP: %d", freeTrainingPoints))
 else
  trainingText:SetText("Unused TP: unavailable")
 end
 updateHappiness(petGUID, petName)
 if PackMateForeverDatabase.visible ~= false then petDisplay:Show() else petDisplay:Hide() end
end
addonFrame:RegisterEvent("ADDON_LOADED")
addonFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
addonFrame:RegisterEvent("UNIT_PET")
addonFrame:RegisterEvent("UNIT_LEVEL")
pcall(addonFrame.RegisterEvent, addonFrame, "UNIT_PET_EXPERIENCE")
pcall(addonFrame.RegisterEvent, addonFrame, "PET_BAR_UPDATE")
pcall(addonFrame.RegisterEvent, addonFrame, "PET_TALENT_UPDATE")
-- PET_HAPPINESS_UPDATE was removed from some Classic builds. The existing
-- one-second OnUpdate polling handles mood changes without this event.
-- Do not register PET_HAPPINESS_UPDATE: it aborts the entire addon at startup.
addonFrame:SetScript("OnEvent",function(self,event,argument)
 if event=="ADDON_LOADED" then
  if argument~="PackMate_F" then return end
  PackMateForeverDatabase=PackMateForeverDatabase or {pets={},visible=true}
  PackMateForeverDatabase.pets=PackMateForeverDatabase.pets or {}
  if PackMateForeverDatabase.announceExperience == nil then PackMateForeverDatabase.announceExperience = true end
  if PackMateForeverDatabase.happinessMode ~= "sassy" and PackMateForeverDatabase.happinessMode ~= "stoic" and PackMateForeverDatabase.happinessMode ~= "mute" then PackMateForeverDatabase.happinessMode = "sassy" end
  -- Migrate old, oversized HUD settings to the compact layout once.
  if PackMateForeverDatabase.hudLayoutVersion ~= 4 then
   PackMateForeverDatabase.size={width=165,height=49}
   PackMateForeverDatabase.hudLayoutVersion=4
  end
  if PackMateForeverDatabase.size then
   petDisplay:SetSize(math.max(145,math.min(280,PackMateForeverDatabase.size.width or 165)), math.max(48,math.min(90,PackMateForeverDatabase.size.height or 49)))
  end
  if PackMateForeverDatabase.position then
   local p=PackMateForeverDatabase.position
   petDisplay:ClearAllPoints()
   petDisplay:SetPoint(p.anchor or "CENTER",UIParent,p.relativeAnchor or "CENTER",p.x or 0,p.y or 0)
  end
  petDisplay:Hide(); return
 end
 if event=="UNIT_LEVEL" and argument~="pet" then return end
 if event=="UNIT_PET" and argument~="player" then return end
 if PackMateForeverDatabase then
  local okay = pcall(updatePetInformation)
  if not okay then activeExperienceSample = nil end
 end
end)
local elapsedSinceRefresh=0
addonFrame:SetScript("OnUpdate",function(_,elapsed)
 elapsedSinceRefresh=elapsedSinceRefresh+elapsed
 if elapsedSinceRefresh>=1 then
  elapsedSinceRefresh=0
  if PackMateForeverDatabase then
  local okay = pcall(updatePetInformation)
  if not okay then activeExperienceSample = nil end
 end
 end
end)
SLASH_PACKMATE1="/pm"
SLASH_PACKMATE2="/petledger"
SLASH_PACKMATE3="/packmate"
SlashCmdList.PACKMATE=function(command)
 if not PackMateForeverDatabase then return end
 command=(command or ""):lower():match("^%s*(.-)%s*$")
 if command=="sassy" or command=="stoic" or command=="mute" then
  PackMateForeverDatabase.happinessMode=command
  -- Switching modes discards prior escalation timers, without sending stale messages.
  happinessChangedAt=GetTime()
  deliveredReminderStages={}
  if command~="mute" then announce("Happiness announcements: " .. command .. ".") end
 elseif command=="show" then PackMateForeverDatabase.visible=true;updatePetInformation()
 elseif command=="hide" then PackMateForeverDatabase.visible=false;petDisplay:Hide()
 elseif command=="reset" then
  PackMateForeverDatabase.size={width=165,height=49}
  PackMateForeverDatabase.hudLayoutVersion=4
  petDisplay:SetSize(165,49)
  petDisplay:ClearAllPoints()
  petDisplay:SetPoint("CENTER", UIParent, "CENTER", 0, -155)
  PackMateForeverDatabase.position={anchor="CENTER",relativeAnchor="CENTER",x=0,y=-155}
  PackMateForeverDatabase.visible=true
  updatePetInformation()
 elseif command=="xp on" then
  PackMateForeverDatabase.announceExperience=true
  announce("Pet XP chat notifications enabled.")
 elseif command=="xp off" then
  PackMateForeverDatabase.announceExperience=false
  announce("Pet XP chat notifications disabled.")
 elseif command=="status" then
  local petGUID,petName=currentPetIdentity()
  if not petGUID then announce("No active pet.");return end
  local record=PackMateForeverDatabase.pets[petGUID]
  updatePetInformation()
  record=PackMateForeverDatabase.pets[petGUID]
  announce(string.format("%s: level %d; unspent training points: %s. Visit a Pet Trainer and use Beast Training to see available skills.",petName,record.level,record.availableTrainingPoints ~= nil and tostring(record.availableTrainingPoints) or "unavailable"))
  announce(string.format("Observed XP on this session GUID: %d (GUID may change on next login)",record.totalObservedExperience or 0))
 elseif command=="" or command=="help" then
  announce("Mode: " .. PackMateForeverDatabase.happinessMode .. ". /pm sassy | stoic | mute; /pm show | hide | reset | status | xp on | xp off")
 else announce("Unknown command. Use /pm help.") end
end
