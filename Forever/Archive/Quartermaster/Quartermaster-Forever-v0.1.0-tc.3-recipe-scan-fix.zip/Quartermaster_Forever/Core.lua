-- Quartermaster: account-wide SavedVariables storage for one Forever realm.
Quartermaster = Quartermaster or {}
local QM = Quartermaster
QM.version = "0.1.0-tc.3-forever"

local function copyTable(value)
    if type(value) ~= "table" then return value end
    local copy = {}
    for key, entry in pairs(value) do copy[copyTable(key)] = copyTable(entry) end
    return copy
end
QM.Copy = copyTable

function QM.CharacterKey()
    local name = UnitName and UnitName("player")
    if type(name) ~= "string" or name == "" then return nil end
    return name
end

function QM.Initialize()
    if type(QuartermasterForeverDB) ~= "table" then QuartermasterForeverDB = {} end
    local database = QuartermasterForeverDB
    if database.schemaVersion ~= nil and database.schemaVersion ~= 1 then
        QM.disabled = true
        return false, "Unsupported Quartermaster data version; no changes were made"
    end
    database.schemaVersion = 1
    database.characters = database.characters or {}
    database.inventory = database.inventory or {}
    database.requisitions = database.requisitions or { byID = {}, order = {} }
    database.requisitions.byID = database.requisitions.byID or {}
    database.requisitions.order = database.requisitions.order or {}
    database.nextRequisitionSequence = database.nextRequisitionSequence or 1
    database.crafting = database.crafting or {evidenceIDs = {}, history = {}}
    database.recipeCatalog = database.recipeCatalog or {characters = {}}
    database.settings = database.settings or {diagnostics = false}
    QM.database = database
    local character = QM.CharacterKey()
    if character then
        database.characters[character] = database.characters[character] or {firstSeen = time and time() or 0}
    end
    return true
end

local eventFrame = CreateFrame("Frame")
eventFrame:RegisterEvent("PLAYER_LOGIN")
eventFrame:SetScript("OnEvent", function()
    local ok, message = QM.Initialize()
    if not ok then print("|cffff6666Quartermaster:|r " .. message); return end
    if QM.RefreshInventory then QM.RefreshInventory() end
end)
