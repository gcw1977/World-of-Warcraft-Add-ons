-- Quartermaster test interface. No protected or automated gameplay actions.
local QM = Quartermaster
local frame, listRows, statusLabel, purposeBox, itemBox, quantityBox, countBox
local currentMode = "requisitions"
local selectedID, selectedLine = nil, 1
local selectedBrowserItemID, selectedBrowserItemName = nil, nil
local function say(message)
    if DEFAULT_CHAT_FRAME then DEFAULT_CHAT_FRAME:AddMessage("|cff66ccffQuartermaster:|r " .. tostring(message)) end
end
QM.Say = say
local function trim(text) return (text or ""):match("^%s*(.-)%s*$") end
local function button(parent, caption, width, height, x, y, action)
    local control = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
    control:SetSize(width, height)
    control:SetPoint("TOPLEFT", parent, "TOPLEFT", x, y)
    control:SetText(caption)
    control:SetScript("OnClick", action)
    return control
end
local function input(parent, width, x, y, initial)
    local control = CreateFrame("EditBox", nil, parent, "InputBoxTemplate")
    control:SetSize(width, 22)
    control:SetPoint("TOPLEFT", parent, "TOPLEFT", x, y)
    control:SetAutoFocus(false)
    control:SetText(initial or "")
    control:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
    control:SetScript("OnEnterPressed", function(self) self:ClearFocus() end)
    return control
end
local function label(parent, text, x, y)
    local font = parent:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    font:SetPoint("TOPLEFT", parent, "TOPLEFT", x, y)
    font:SetText(text)
    return font
end
local function repaint()
    if QM.RefreshHUD then QM.RefreshHUD() end
    if not frame or not frame:IsShown() then return end
    local rows = {}
    if currentMode == "shopping" then
        for _, entry in pairs(QM.GetShoppingList()) do table.insert(rows, entry) end
        table.sort(rows, function(a, b) return a.itemID < b.itemID end)
        statusLabel:SetText("Shopping list: combined unmet requisition demand (not inventory allocation)")
    elseif currentMode == "inventory" then
        local keys = {}
        for who in pairs(QM.database.characters or {}) do table.insert(keys, who) end
        table.sort(keys)
        for _, who in ipairs(keys) do
            local bagCount, bankCount = 0, 0
            local inventory = QM.database.inventory[who] or {}
            if inventory.bags then for _, count in pairs(inventory.bags.itemsByItemID) do bagCount = bagCount + count end end
            if inventory.bank then for _, count in pairs(inventory.bank.itemsByItemID) do bankCount = bankCount + count end end
            table.insert(rows, {who=who, bags=inventory.bags and bagCount or "unknown", bank=inventory.bank and bankCount or "unknown"})
        end
        statusLabel:SetText("Inventory: retained per-character snapshots; bank unknown until visited")
    else
        for _, record in ipairs(QM.ListRequisitions()) do
            if (currentMode == "completed" and record.status == "closed") or
               (currentMode == "requisitions" and record.status ~= "closed") then
                table.insert(rows, record)
            end
        end
        statusLabel:SetText(currentMode == "completed" and
            "Completed requisitions: owner may reopen or delete" or
            "Active requisitions: select one; owner-only changes")
    end
    local displayed = math.min(#rows, #listRows)
    for index, row in ipairs(listRows) do
        local entry = rows[index]
        if entry then
            local text
            if currentMode == "shopping" then
                local owned, missingBank = QM.CountAcrossCharacters(entry.itemID)
                text = string.format("%s | needed %d | observed %d%s", QM.ItemName(entry.itemID, entry.name),
                    entry.quantity, owned, missingBank > 0 and " | bank unknown" or "")
            elseif currentMode == "inventory" then
                text = string.format("%s | bags: %s | bank: %s", entry.who, tostring(entry.bags), tostring(entry.bank))
            else
                local summary = entry.type == "recipe" and (" | crafts " .. entry.recipe.completedCrafts .. "/" .. entry.recipe.requestedCrafts) or ""
                text = string.format("%s [%s] %s: %s (%s)%s", entry.id, entry.ownerKey,
                    entry.type, entry.purpose, entry.status, summary)
                if entry.id == selectedID then text = "> " .. text end
            end
            row:SetText(text)
            row.entryID = (currentMode == "requisitions" or currentMode == "completed") and entry.id or nil
            row:Show()
        else row:Hide() end
    end
    if #rows > displayed then statusLabel:SetText(statusLabel:GetText() .. " | showing first " .. displayed .. " of " .. #rows) end
end
QM.RefreshUI = repaint
StaticPopupDialogs["QUARTERMASTER_CONFIRM_DELETE"] = {
    text = "Permanently delete requisition %s? This cannot be undone.",
    button1 = YES,
    button2 = NO,
    OnAccept = function(_, requisitionID)
        local ok, err = QM.DeleteRequisition(requisitionID)
        if ok then
            if selectedID == requisitionID then selectedID = nil; selectedLine = 1 end
            say("Deleted " .. requisitionID)
        else
            say("Deletion failed: " .. tostring(err))
        end
        repaint()
    end,
    timeout = 0,
    whileDead = true,
    hideOnEscape = true,
    preferredIndex = 3,
}
local function createWindow()
    frame = CreateFrame("Frame", "QuartermasterMainFrame", UIParent, "BackdropTemplate")
    frame:SetSize(760, 520)
    frame:SetPoint("CENTER")
    frame:SetFrameStrata("DIALOG")
    frame:SetMovable(true)
    frame:EnableMouse(true)
    frame:RegisterForDrag("LeftButton")
    frame:SetScript("OnDragStart", frame.StartMoving)
    frame:SetScript("OnDragStop", frame.StopMovingOrSizing)
    frame:SetBackdrop({bgFile="Interface\\DialogFrame\\UI-DialogBox-Background", edgeFile="Interface\\DialogFrame\\UI-DialogBox-Border", edgeSize=32, insets={left=8,right=8,top=8,bottom=8}})
    label(frame, "QUARTERMASTER  |  FOREVER TC 0.1.0", 24, -20)
    button(frame, "X", 26, 22, 711, -18, function() frame:Hide() end)
    button(frame, "Requisitions", 125, 25, 20, -56, function() currentMode="requisitions"; repaint() end)
    button(frame, "Completed", 105, 25, 153, -56, function() currentMode="completed"; repaint() end)
    button(frame, "Shopping", 105, 25, 266, -56, function() currentMode="shopping"; repaint() end)
    button(frame, "Inventory", 105, 25, 379, -56, function() currentMode="inventory"; repaint() end)
    statusLabel = label(frame, "", 22, -92)
    listRows = {}
    for index = 1, 11 do
        local row = button(frame, "", 718, 24, 20, -112 - ((index-1) * 27), function(self)
            if self.entryID then selectedID = self.entryID; selectedLine = 1; repaint() end
        end)
        row:GetFontString():SetJustifyH("LEFT")
        listRows[index] = row
    end
    label(frame, "Purpose", 23, -401)
    purposeBox = input(frame, 256, 24, -418)
    label(frame, "Item / learned recipe name", 302, -401)
    itemBox = input(frame, 250, 302, -418)
    itemBox:SetScript("OnTextChanged", function() selectedBrowserItemID=nil; selectedBrowserItemName=nil end)
    button(frame, "Browse", 70, 24, 478, -391, function()
        QM.OpenLearnedOutputBrowser(function(itemID, itemName)
            itemBox:SetText(itemName)
            selectedBrowserItemID=itemID; selectedBrowserItemName=itemName
        end)
    end)
    label(frame, "Qty", 578, -401)
    quantityBox = input(frame, 55, 578, -418, "1")
    label(frame, "Crafts", 659, -401)
    countBox = input(frame, 55, 659, -418, "1")
    button(frame, "Create manual", 120, 25, 20, -453, function()
        local itemID, itemName, resolveError
        if selectedBrowserItemID then itemID, itemName = selectedBrowserItemID, selectedBrowserItemName
        else itemID, itemName, resolveError = QM.ResolveItem(trim(itemBox:GetText())) end
        if not itemID then say("Item lookup failed: " .. tostring(resolveError)); return end
        local qty = tonumber(trim(quantityBox:GetText()))
        local ok, result = QM.CreateManual(trim(purposeBox:GetText()), {{itemID=itemID, requiredQuantity=qty, name=itemName}})
        say(ok and ("Created " .. result) or ("Creation failed: " .. tostring(result)))
        repaint()
    end)
    button(frame, "Plan recipe", 120, 25, 148, -453, function()
        local ok, result = QM.PlanLearnedRecipe(tonumber(countBox:GetText()) or 1, trim(itemBox:GetText()))
        say(ok and ("Imported " .. result) or ("Import failed: " .. tostring(result)))
        repaint()
    end)
    button(frame, "Toggle acquired", 135, 25, 276, -453, function()
        local rec = QM.database.requisitions.byID[selectedID or ""]
        local line = rec and rec.materials[selectedLine]
        local ok, err = line and QM.SetAcquired(selectedID, line.lineID, not line.acquired)
        say(ok and ("Updated " .. selectedID .. " line " .. selectedLine) or ("Failed: " .. tostring(err or "SELECT_REQUISITION")))
        repaint()
    end)
    button(frame, "Complete / Reopen", 155, 25, 419, -453, function()
        local rec = QM.database.requisitions.byID[selectedID or ""]
        local ok, err = rec and QM.SetComplete(selectedID, rec.status ~= "closed")
        say(ok and "Status updated" or ("Failed: " .. tostring(err or "SELECT_REQUISITION")))
        repaint()
    end)
    button(frame, "Delete", 75, 25, 582, -453, function()
        local record = QM.database.requisitions.byID[selectedID or ""]
        if not record then say("Select a requisition to delete."); return end
        if record.ownerKey ~= QM.CharacterKey() then say("Only the owner can delete this requisition."); return end
        StaticPopup_Show("QUARTERMASTER_CONFIRM_DELETE", record.id .. " - " .. tostring(record.purpose), nil, record.id)
    end)
    button(frame, "Help", 65, 25, 666, -453, function() QM.PrintHelp() end)
    label(frame, "Completed requests live under Completed. Deletion is permanent and owner-only.", 20, -492)
    frame:Hide()
end
function QM.ToggleWindow(mode)
    if not frame then createWindow() end
    if mode then currentMode=mode end
    if frame:IsShown() then frame:Hide() else frame:Show(); repaint() end
end
function QM.PrintHelp()
    for _, line in ipairs({
        "/qm or /rf - open Quartermaster window", "/qm list | completed | shop | inventory - open selected view",
        "/qm new <purpose> | <itemID>:<qty>[,<itemID>:<qty>...] - create manual request",
        "/qm plan <count> | <exact learned recipe> [| crafter] - create material requisition",
        "/qm catalog - show saved profession counts; /qm catalog <item name> - search recipes",
        "/qm scan - rescan the open profession window",
        "/qm hud show|hide|toggle|reset - per-character requisition notes",
        "/qm lines <QM-ID> - show material lines; /qm acquired <QM-ID> <line> on|off",
        "/qm complete <QM-ID> | /qm reopen <QM-ID> - manual status",
        "/qm delete <QM-ID> - permanently delete owned requisition (confirmation required)",
        "/qm crafts <QM-ID> <count> - manually update completed recipe crafts",
                "/qm bank - scan bank while bank is open; /qm help - show this help"
    }) do say(line) end
end
local function handle(command)
    if not QM.database then say("Database not ready. If this persists, reload the UI."); return end
    local text = trim(command)
    if text == "" then QM.ToggleWindow(); return end
    local verb, rest = text:match("^(%S+)%s*(.*)$")
    verb = verb:lower()
    if verb == "help" then QM.PrintHelp()
    elseif verb == "list" then QM.ToggleWindow("requisitions")
    elseif verb == "completed" then QM.ToggleWindow("completed")
    elseif verb == "shop" then QM.ToggleWindow("shopping")
    elseif verb == "inventory" then QM.ToggleWindow("inventory")
    elseif verb == "bank" then say(QM.RefreshBank() and "Bank snapshot updated." or "Open your bank first.")
    elseif verb == "hud" then
        local option = trim(rest):lower()
        if option == "reset" then QM.ResetHUDPosition(); QM.ToggleHUD(true)
        elseif option == "show" then QM.ToggleHUD(true)
        elseif option == "hide" then QM.ToggleHUD(false)
        elseif option == "toggle" or option == "" then QM.ToggleHUD()
        else say("Usage: /qm hud show|hide|toggle|reset") end
    elseif verb == "scan" then
        local scanned, reason = QM.ScanOpenProfession()
        QM.lastProfessionScan = {count=scanned, reason=reason, time=time and time() or 0}
        say(scanned and ("Scanned " .. scanned .. " learned recipes; saved to account catalog.")
            or ("Recipe scan not saved: " .. tostring(reason)))
    elseif verb == "catalog" then
        if trim(rest) == "" then
            local summary = QM.CatalogSummary()
            if #summary == 0 then say("Catalog empty. Open a profession window on a character to scan.") end
            for _, entry in ipairs(summary) do
                say(string.format("%s | %s | %d known recipes%s", entry.character, entry.profession, entry.count,
                    entry.skillRank and (" | skill " .. entry.skillRank .. "/" .. (entry.skillMax or "?")) or ""))
            end
        else
            local found = QM.CatalogFind(trim(rest))
            say("Matching catalog recipes: " .. #found)
            for index = 1, math.min(#found, 20) do
                local entry = found[index]
                say(string.format("%s | %s | %s%s", entry.character, entry.profession, entry.recipe.name,
                    entry.recipe.verifiedReagents and " | materials saved" or " | materials unavailable"))
            end
            if #found > 20 then say("Showing first 20 matches; narrow your search.") end
        end
    elseif verb == "new" then
        local purpose, spec = rest:match("^(.-)%s*|%s*(.+)$")
        local lines = {}
        if spec then
            for token in spec:gmatch("[^,]+") do
                local itemInput, qty = token:match("^%s*(.-)%s*:%s*(%d+)%s*$")
                if not itemInput then say("Bad material format. Example: Light Leather:5"); return end
                local itemID, itemName, resolveError = QM.ResolveItem(itemInput)
                if not itemID then say("Item lookup failed: " .. tostring(resolveError)); return end
                qty = tonumber(qty)
                table.insert(lines, {itemID=itemID, requiredQuantity=qty, name=itemName or tostring(itemID)})
            end
        end
        local ok, result = QM.CreateManual(trim(purpose or ""), lines)
        say(ok and ("Created " .. result) or ("Failed: " .. tostring(result)))
        repaint()
    elseif verb == "plan" then
        local count, recipeName, crafter = rest:match("^(%d+)%s*|%s*(.-)%s*|%s*(.-)%s*$")
        if not count then count, recipeName = rest:match("^(%d+)%s*|%s*(.+)$") end
        if not count then say("Usage: /qm plan 3 | Light Armor Kit [| Clint]"); return end
        local ok, result = QM.PlanLearnedRecipe(tonumber(count), trim(recipeName), crafter and trim(crafter))
        say(ok and ("Created " .. result) or ("Plan failed: " .. tostring(result)))
        repaint()
    elseif verb == "lines" then
        local record = QM.database.requisitions.byID[trim(rest)]
        if not record then say("Requisition not found"); return end
        for _, line in ipairs(record.materials) do
            say(string.format("%s line %d | %s (%d) x%d | acquired %s", record.id, line.lineID,
                line.name, line.itemID, line.requiredQuantity, tostring(line.acquired)))
        end
    elseif verb == "acquired" then
        local id, lineID, choice = rest:match("^(%S+)%s+(%d+)%s+(%S+)$")
        if not id or (choice ~= "on" and choice ~= "off") then say("Usage: /qm acquired QM-1 1 on|off"); return end
        local ok, err = QM.SetAcquired(id, tonumber(lineID), choice == "on")
        say(ok and "Material updated" or ("Failed: " .. tostring(err)))
        repaint()
    elseif verb == "complete" or verb == "reopen" then
        local ok, err = QM.SetComplete(trim(rest), verb == "complete")
        say(ok and "Requisition updated" or ("Failed: " .. tostring(err)))
        repaint()
    elseif verb == "delete" then
        local identifier = trim(rest)
        local record = QM.database.requisitions.byID[identifier]
        if not record then say("Requisition not found"); return end
        if record.ownerKey ~= QM.CharacterKey() then say("Only the owner can delete this requisition."); return end
        StaticPopup_Show("QUARTERMASTER_CONFIRM_DELETE", record.id .. " - " .. tostring(record.purpose), nil, record.id)
    elseif verb == "crafts" then
        local id, qty = rest:match("^(%S+)%s+(%d+)$")
        local ok, err = QM.SetCraftCount(id, tonumber(qty))
        say(ok and "Craft counter updated" or ("Failed: " .. tostring(err)))
        repaint()
    else QM.PrintHelp() end
end
SLASH_QUARTERMASTER1 = "/qm"
SlashCmdList.QUARTERMASTER = handle
SLASH_REQUISITIONFORMS1 = "/rf"
SlashCmdList.REQUISITIONFORMS = handle
