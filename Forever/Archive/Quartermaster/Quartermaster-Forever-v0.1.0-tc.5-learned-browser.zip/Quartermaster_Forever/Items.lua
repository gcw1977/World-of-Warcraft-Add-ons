-- Item display and entry: use item cache, known reagent names, and item links.
local QM = Quartermaster
local function normalized(text)
    if type(text) ~= "string" then return nil end
    return text:match("^%s*(.-)%s*$"):lower()
end
function QM.ItemName(itemID, fallback)
    local name = GetItemInfo and GetItemInfo(itemID)
    if name then return name end
    if fallback and fallback ~= tostring(itemID) then return fallback end
    if QM.database then
        for _, record in pairs(QM.database.requisitions.byID or {}) do
            for _, line in ipairs(record.materials or {}) do
                if line.itemID == itemID and line.name and line.name ~= tostring(itemID) then return line.name end
            end
        end
    end
    return tostring(itemID)
end
function QM.ResolveItem(inputText)
    if type(inputText) ~= "string" then return nil, nil, "EMPTY_ITEM" end
    local id = tonumber(inputText:match("item:(%d+)")) or tonumber(inputText:match("^%s*(%d+)%s*$"))
    if id and id > 0 and id % 1 == 0 then return id, QM.ItemName(id) end
    local search = normalized(inputText)
    if not search or search == "" then return nil, nil, "EMPTY_ITEM" end
    if QM.database then
        for _, record in pairs(QM.database.requisitions.byID or {}) do
            for _, line in ipairs(record.materials or {}) do
                if normalized(line.name) == search then return line.itemID, line.name end
            end
        end
    end
    -- The client may resolve exact names already in its item cache, but not arbitrary uncached names.
    if GetItemInfo then
        local name, link = GetItemInfo(inputText:match("^%s*(.-)%s*$"))
        id = type(link) == "string" and tonumber(link:match("item:(%d+)")) or nil
        if id then return id, name end
    end
    if GetItemInfoInstant then
        local instantID = GetItemInfoInstant(inputText:match("^%s*(.-)%s*$"))
        if type(instantID) == "number" and instantID > 0 then return instantID, QM.ItemName(instantID, inputText) end
    end
    return nil, nil, "ITEM_NOT_CACHED_OR_UNKNOWN (shift-click item or enter ID)"
end
