-- Quartermaster inventory: last-observed counts; offline does not invalidate snapshots.
local QM = Quartermaster
local observer = CreateFrame("Frame")
local bankOpen = false
local function now() return time and time() or 0 end
local function scan(bagIDs)
    if not C_Container or not C_Container.GetContainerNumSlots or not C_Container.GetContainerItemInfo then return nil end
    local items = {}
    for _, bagID in ipairs(bagIDs) do
        local slots = C_Container.GetContainerNumSlots(bagID) or 0
        for slotID = 1, slots do
            local item = C_Container.GetContainerItemInfo(bagID, slotID)
            if item and item.itemID then items[item.itemID] = (items[item.itemID] or 0) + (item.stackCount or 1) end
        end
    end
    return items
end
function QM.RefreshInventory()
    if QM.disabled or not QM.database then return false end
    local who = QM.CharacterKey()
    if not who then return false end
    local bagIDs = {}
    for bagID = 0, (NUM_BAG_SLOTS or 4) do table.insert(bagIDs, bagID) end
    local items = scan(bagIDs)
    if not items then return false end
    local record = QM.database.inventory[who] or {}
    record.bags = {itemsByItemID=items, observedAt=now(), coverage="known"}
    QM.database.inventory[who] = record
    if QM.RefreshUI then QM.RefreshUI() end
    return true
end
function QM.RefreshBank()
    if not bankOpen or QM.disabled or not QM.database then return false end
    local who = QM.CharacterKey()
    if not who then return false end
    local firstBankBag = (NUM_BAG_SLOTS or 4) + 1
    local bagIDs = {BANK_CONTAINER or -1}
    for bankBagID = firstBankBag, firstBankBag + (NUM_BANKBAGSLOTS or 7) - 1 do
        table.insert(bagIDs, bankBagID)
    end
    local items = scan(bagIDs)
    if not items then return false end
    local record = QM.database.inventory[who] or {}
    record.bank = {itemsByItemID=items, observedAt=now(), coverage="known"}
    QM.database.inventory[who] = record
    if QM.RefreshUI then QM.RefreshUI() end
    return true
end
function QM.GetItemCount(who, itemID, location)
    local record = QM.database and QM.database.inventory[who]
    local snapshot = record and record[location or "bags"]
    if not snapshot or snapshot.coverage ~= "known" then return nil, "unknown" end
    return snapshot.itemsByItemID[itemID] or 0, "known"
end
function QM.CountAcrossCharacters(itemID)
    local total, unknownBanks = 0, 0
    if not QM.database then return 0, 0 end
    for who in pairs(QM.database.characters) do
        for _, location in ipairs({"bags", "bank"}) do
            local count = QM.GetItemCount(who, itemID, location)
            if count then total = total + count elseif location == "bank" then unknownBanks = unknownBanks + 1 end
        end
    end
    return total, unknownBanks
end
observer:RegisterEvent("BAG_UPDATE_DELAYED")
observer:RegisterEvent("BANKFRAME_OPENED")
observer:RegisterEvent("BANKFRAME_CLOSED")
observer:RegisterEvent("PLAYERBANKSLOTS_CHANGED")
observer:SetScript("OnEvent", function(_, event)
    if event == "BANKFRAME_OPENED" then
        bankOpen = true
        QM.RefreshBank()
    elseif event == "BANKFRAME_CLOSED" then
        QM.RefreshBank()
        bankOpen = false
    elseif event == "PLAYERBANKSLOTS_CHANGED" then
        QM.RefreshBank()
    else
        QM.RefreshInventory()
        if bankOpen then QM.RefreshBank() end
    end
end)
