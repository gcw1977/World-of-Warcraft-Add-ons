-- Forever profession scanner. Reference for API *method*, not code:
-- AltStable Professions by Spotnick2: GetAllRecipeIDs -> GetRecipeInfo(id).learned.
-- Only current logged-in character with its own open profession window is scanned.
-- Fail closed: no database recipe writes without explicit learned == true.
local QM = Quartermaster
local frame = CreateFrame("Frame")
local function checked(functionValue, ...)
    if type(functionValue) ~= "function" then return nil end
    local ok, first, second, third, fourth = pcall(functionValue, ...)
    if ok then return first, second, third, fourth end
    return nil
end
local function itemName(itemID)
    local result = (C_Item and C_Item.GetItemInfo and C_Item.GetItemInfo(itemID)) or (GetItemInfo and GetItemInfo(itemID))
    return result or tostring(itemID)
end
local function extractReagents(schematic)
    if type(schematic) ~= "table" or type(schematic.reagentSlotSchematics) ~= "table" then return nil end
    local materials = {}
    for _, slot in ipairs(schematic.reagentSlotSchematics) do
        local needed = slot.quantityRequired or slot.quantity or 0
        local candidates = slot.reagents
        if needed > 0 then
            -- A choice slot is not a deterministic shopping requirement.
            if type(candidates) ~= "table" or #candidates ~= 1 then return nil end
            local reagent = candidates[1]
            local id = reagent and (reagent.itemID or reagent.itemId)
            if type(id) ~= "number" or id < 1 then return nil end
            materials[#materials + 1] = {itemID=id, name=itemName(id), quantity=needed}
        end
    end
    return materials
end
local function professionName()
    local api = C_TradeSkillUI
    local source = api and checked(api.GetChildProfessionInfo)
    if type(source) == "table" and type(source.professionName) == "string" and source.professionName ~= "" then
        return source.professionName, source.professionID
    end
    local base = api and checked(api.GetBaseProfessionInfo)
    if type(base) == "table" and type(base.professionName) == "string" and base.professionName ~= "" then
        return base.professionName, base.professionID
    end
    return nil
end
-- Forever may use a different frame than the legacy ProfessionsFrame/TradeSkillFrame.
-- The API is authoritative about whether a usable profession is open.
local function professionWindowVisible()
    local api = C_TradeSkillUI
    if api and type(api.IsTradeSkillReady) == "function" then
        return checked(api.IsTradeSkillReady) == true
    end
    return (ProfessionsFrame and ProfessionsFrame.IsShown and ProfessionsFrame:IsShown()) or
           (TradeSkillFrame and TradeSkillFrame.IsShown and TradeSkillFrame:IsShown())
end
local function invalidSource()
    local api = C_TradeSkillUI
    if api and type(api.IsDataSourceChanging) == "function" and checked(api.IsDataSourceChanging) == true then
        return "PROFESSION_SOURCE_CHANGING"
    end
    for _, method in ipairs({"IsTradeSkillLinked", "IsTradeSkillGuild", "IsNPCCrafting"}) do
        if api and type(api[method]) == "function" and checked(api[method]) == true then
            return "NOT_OWN_PROFESSION"
        end
    end
    return nil
end
function QM.ScanOpenProfession()
    if QM.disabled or not QM.database then return nil, "DATABASE_NOT_READY" end
    if not professionWindowVisible() then return nil, "PROFESSION_NOT_READY" end
    local sourceError = invalidSource()
    if sourceError then return nil, sourceError end
    local api = C_TradeSkillUI
    if not api or type(api.GetAllRecipeIDs) ~= "function" or type(api.GetRecipeInfo) ~= "function" then
        return nil, "FOREVER_PROFESSION_API_UNAVAILABLE"
    end
    local profession, professionID = professionName()
    if not profession then return nil, "PROFESSION_IDENTITY_NOT_READY" end
    local character = QM.CharacterKey()
    if not character then return nil, "CHARACTER_NOT_READY" end
    local recipeIDs = checked(api.GetAllRecipeIDs)
    if type(recipeIDs) ~= "table" or #recipeIDs == 0 then return nil, "RECIPE_LIST_NOT_READY" end
    -- Stage a scan before committing. If UI/source changes, do not record partial data.
    local staged, learnedCount = {}, 0
    for _, id in ipairs(recipeIDs) do
        local info = checked(api.GetRecipeInfo, id)
        if type(info) == "table" and info.learned == true and type(info.name) == "string" and info.name ~= "" then
            learnedCount = learnedCount + 1
            local schematic = api.GetRecipeSchematic and checked(api.GetRecipeSchematic, id, false)
            local reagents = extractReagents(schematic)
            local outputItemID = type(schematic) == "table" and (schematic.outputItemID or schematic.outputItemId) or nil
            local key = "recipe:" .. tostring(id)
            staged[key] = {recipeID=id, name=info.name, profession=profession,
                outputItemID=outputItemID, reagents=reagents, verifiedReagents=(reagents ~= nil),
                lastSeen=time and time() or 0, source="forever-learned"}
        end
    end
    local afterName, afterID = professionName()
    if invalidSource() then return nil, "PROFESSION_SOURCE_CHANGED_DURING_SCAN" end
    if not professionWindowVisible() or afterName ~= profession or afterID ~= professionID then
        return nil, "PROFESSION_CHANGED_DURING_SCAN"
    end
    if learnedCount == 0 then return nil, "NO_LEARNED_RECIPES_VISIBLE" end
    QM.database.recipeCatalog = QM.database.recipeCatalog or { characters = {} }
    local catalog = QM.database.recipeCatalog
    catalog.characters = catalog.characters or {}
    local characterData = catalog.characters[character] or {professions={}}
    characterData.professions = characterData.professions or {}
    local professionData = characterData.professions[profession] or {recipes={}}
    professionData.recipes = professionData.recipes or {}
    for key, recipe in pairs(staged) do
        local previous = professionData.recipes[key]
        if not recipe.verifiedReagents and previous and previous.verifiedReagents then
            recipe.reagents, recipe.verifiedReagents = previous.reagents, true
        end
        professionData.recipes[key] = recipe
    end
    -- Deliberately never delete unseen entries: filtered/incomplete lists are not unlearning.
    professionData.lastScan=time and time() or 0
    professionData.visibleRecipes=learnedCount
    professionData.professionID=professionID
    characterData.professions[profession]=professionData
    catalog.characters[character]=characterData
    return learnedCount, "OK"
end
function QM.CatalogSummary()
    local output={}
    for character, data in pairs(QM.database and QM.database.recipeCatalog.characters or {}) do
        for profession, record in pairs(data.professions or {}) do
            local count=0
            for _ in pairs(record.recipes or {}) do count=count+1 end
            output[#output+1]={character=character,profession=profession,count=count}
        end
    end
    table.sort(output,function(a,b) if a.character==b.character then return a.profession<b.profession end return a.character<b.character end)
    return output
end
function QM.CatalogFind(search)
    local output={}
    if type(search)~="string" or search=="" then return output end
    local needle=search:lower()
    for character, data in pairs(QM.database and QM.database.recipeCatalog.characters or {}) do
        for profession, record in pairs(data.professions or {}) do
            for _,recipe in pairs(record.recipes or {}) do
                if recipe.name and recipe.name:lower():find(needle,1,true) then
                    output[#output+1]={character=character,profession=profession,recipe=QM.Copy(recipe)}
                end
            end
        end
    end
    table.sort(output,function(a,b)
        if a.recipe.name~=b.recipe.name then return a.recipe.name<b.recipe.name end
        return a.character<b.character
    end)
    return output
end
-- Explicit request: produce requisition materials from a recipe actually observed as learned.
-- Character requesting the craft owns the form; the catalog's character is the suggested crafter.
function QM.PlanLearnedRecipe(crafts, name, crafter)
    crafts=tonumber(crafts)
    if not crafts or crafts<1 or crafts%1~=0 or type(name)~="string" or name=="" then return false,"INVALID_REQUEST" end
    local matches={}
    for _, entry in ipairs(QM.CatalogFind(name)) do
        if entry.recipe.name:lower()==name:lower() and (not crafter or entry.character:lower()==crafter:lower()) then
            matches[#matches+1]=entry
        end
    end
    if #matches==0 then return false,"RECIPE_NOT_LEARNED_IN_ACCOUNT_CATALOG" end
    if #matches>1 then return false,"AMBIGUOUS_RECIPE_SPECIFY_CRAFTER" end
    local entry=matches[1]
    if not entry.recipe.verifiedReagents or type(entry.recipe.reagents)~="table" or #entry.recipe.reagents==0 then
        return false,"MATERIALS_UNAVAILABLE_FOR_THIS_RECIPE"
    end
    local lines={}
    for _, reagent in ipairs(entry.recipe.reagents) do
        lines[#lines+1]={itemID=reagent.itemID,name=reagent.name,requiredQuantity=reagent.quantity*crafts}
    end
    return QM.CreateRecipe(entry.recipe.name,lines,{name=entry.recipe.name,profession=entry.profession,
        requestedCrafts=crafts,outputItemID=entry.recipe.outputItemID,crafterKey=entry.character})
end
-- Keep scan failures visible via /qm scan; automatic scans are deliberately quiet.
-- A short delay allows Forever's asynchronously populated recipe list to settle.
local scanGeneration = 0
local function queueScan()
    scanGeneration = scanGeneration + 1
    local generation = scanGeneration
    if not C_Timer or type(C_Timer.After) ~= "function" then
        QM.ScanOpenProfession()
        return
    end
    local function attempt(remaining)
        if generation ~= scanGeneration then return end
        local count, reason = QM.ScanOpenProfession()
        QM.lastProfessionScan = {count=count, reason=reason, time=time and time() or 0}
        if not count and remaining > 0 and
            (reason == "PROFESSION_NOT_READY" or reason == "RECIPE_LIST_NOT_READY" or
             reason == "PROFESSION_IDENTITY_NOT_READY" or reason == "PROFESSION_SOURCE_CHANGING" or
             reason == "NO_LEARNED_RECIPES_VISIBLE") then
            C_Timer.After(0.5, function() attempt(remaining-1) end)
        end
    end
    C_Timer.After(0.4, function() attempt(5) end)
end
for _, event in ipairs({"TRADE_SKILL_SHOW", "TRADE_SKILL_LIST_UPDATE", "TRADE_SKILL_DATA_SOURCE_CHANGED", "TRADE_SKILL_UPDATE", "NEW_RECIPE_LEARNED", "TRADE_SKILL_CLOSE"}) do
    -- Some event identifiers differ by client; registering nonexistent events can throw.
    pcall(frame.RegisterEvent, frame, event)
end
frame:SetScript("OnEvent", function(_, event)
    if event == "TRADE_SKILL_CLOSE" then
        scanGeneration = scanGeneration + 1
    else
        queueScan()
    end
end)
