-- Quartermaster Forever: current-character requisition post-its.
-- Never infer "Acquired" from inventory: stock is not assigned to demand.
-- This UI edits only requests owned by the logged-in character.
local QM = Quartermaster
local hud, canvas, scrollFrame, emptyLabel, titleLabel
local notes = {}
local PANEL_WIDTH, PANEL_HEIGHT = 292, 370
local NOTE_WIDTH, LINE_HEIGHT = 254, 19
local NOTE_GAP = 9

local function makeButton(parent, caption, width, height, action)
    local control = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
    control:SetSize(width, height)
    control:SetText(caption)
    control:SetScript("OnClick", action)
    return control
end

local function textLabel(parent, template)
    local text = parent:CreateFontString(nil, "OVERLAY", template or "GameFontNormalSmall")
    text:SetJustifyH("LEFT")
    return text
end

local function hudSettings()
    if not QM.database then return nil end
    QM.database.settings = QM.database.settings or {}
    QM.database.settings.requisitionHUD = QM.database.settings.requisitionHUD or { visible = true }
    return QM.database.settings.requisitionHUD
end

local function savePosition(frame)
    local settings = hudSettings()
    if not settings then return end
    local centerX, centerY = frame:GetCenter()
    local parentWidth, parentHeight = UIParent:GetWidth(), UIParent:GetHeight()
    if centerX and centerY and parentWidth > 0 and parentHeight > 0 then
        settings.x = centerX - parentWidth / 2
        settings.y = centerY - parentHeight / 2
    end
end

local function setPosition()
    if not hud then return end
    local settings = hudSettings()
    hud:ClearAllPoints()
    if settings and type(settings.x) == "number" and type(settings.y) == "number" then
        hud:SetPoint("CENTER", UIParent, "CENTER", settings.x, settings.y)
    else
        hud:SetPoint("RIGHT", UIParent, "RIGHT", -35, 30)
    end
end

local function createHUD()
    hud = CreateFrame("Frame", "QuartermasterRequisitionHUD", UIParent, "BackdropTemplate")
    hud:SetSize(PANEL_WIDTH, PANEL_HEIGHT)
    hud:SetFrameStrata("MEDIUM")
    hud:SetClampedToScreen(true)
    hud:SetMovable(true)
    hud:EnableMouse(true)
    hud:RegisterForDrag("LeftButton")
    hud:SetScript("OnDragStart", hud.StartMoving)
    hud:SetScript("OnDragStop", function(self) self:StopMovingOrSizing(); savePosition(self) end)
    hud:SetBackdrop({bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
        edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", edgeSize = 14,
        insets = {left = 4, right = 4, top = 4, bottom = 4}})
    titleLabel = textLabel(hud, "GameFontNormal")
    titleLabel:SetPoint("TOPLEFT", hud, "TOPLEFT", 13, -13)
    titleLabel:SetText("QUARTERMASTER  |  REQUISITIONS")
    local closeButton = makeButton(hud, "X", 25, 22, function()
        local settings = hudSettings()
        if settings then settings.visible = false end
        hud:Hide()
    end)
    closeButton:SetPoint("TOPRIGHT", hud, "TOPRIGHT", -8, -8)
    scrollFrame = CreateFrame("ScrollFrame", "QuartermasterRequisitionHUDScroll", hud, "UIPanelScrollFrameTemplate")
    scrollFrame:SetPoint("TOPLEFT", hud, "TOPLEFT", 9, -44)
    scrollFrame:SetPoint("BOTTOMRIGHT", hud, "BOTTOMRIGHT", -31, 9)
    canvas = CreateFrame("Frame", nil, scrollFrame)
    canvas:SetWidth(NOTE_WIDTH)
    canvas:SetHeight(1)
    scrollFrame:SetScrollChild(canvas)
    emptyLabel = textLabel(canvas, "GameFontHighlightSmall")
    emptyLabel:SetPoint("TOPLEFT", canvas, "TOPLEFT", 10, -16)
    emptyLabel:SetWidth(NOTE_WIDTH - 20)
    setPosition()
    hud:Hide()
end

local function noteAt(index)
    if notes[index] then return notes[index] end
    local note = CreateFrame("Frame", nil, canvas, "BackdropTemplate")
    note:SetWidth(NOTE_WIDTH)
    note:SetBackdrop({bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", edgeSize = 10,
        insets = {left = 3, right = 3, top = 3, bottom = 3}})
    note:SetBackdropColor(0.22, 0.19, 0.08, 0.95)
    note:SetBackdropBorderColor(0.65, 0.55, 0.28, 0.85)
    note.heading = textLabel(note, "GameFontNormal")
    note.heading:SetPoint("TOPLEFT", note, "TOPLEFT", 9, -9)
    note.heading:SetWidth(NOTE_WIDTH - 94)
    note.complete = makeButton(note, "Done", 65, 21, function(self)
        if QM.SetComplete and self.requisitionID then
            local ok, reason = QM.SetComplete(self.requisitionID, true)
            if not ok and QM.Say then QM.Say("Could not complete: " .. tostring(reason)) end
            if QM.RefreshUI then QM.RefreshUI() end
        end
    end)
    note.complete:SetPoint("TOPRIGHT", note, "TOPRIGHT", -7, -5)
    note.lines = {}
    notes[index] = note
    return note
end

local function lineAt(note, index)
    if note.lines[index] then return note.lines[index] end
    local line = {}
    line.check = CreateFrame("CheckButton", nil, note, "UICheckButtonTemplate")
    line.check:SetSize(21, 21)
    line.check:SetPoint("TOPLEFT", note, "TOPLEFT", 6, -35 - (index - 1) * LINE_HEIGHT)
    line.text = textLabel(note, "GameFontHighlightSmall")
    line.text:SetPoint("LEFT", line.check, "RIGHT", 1, 0)
    line.text:SetWidth(NOTE_WIDTH - 40)
    line.check:SetScript("OnClick", function(self)
        local ok, reason = QM.SetAcquired(self.requisitionID, self.lineID, self:GetChecked() == true)
        if not ok and QM.Say then QM.Say("Could not update item: " .. tostring(reason)) end
        if QM.RefreshUI then QM.RefreshUI() end
    end)
    note.lines[index] = line
    return line
end

-- Rebuild presentation from saved requisitions; no independent HUD demand cache.
function QM.RefreshHUD()
    if not QM.database or QM.disabled then return end
    if not hud then createHUD() end
    local settings = hudSettings()
    if not settings or settings.visible == false then hud:Hide(); return end
    hud:Show()
    local character = QM.CharacterKey()
    local requisitions = QM.ListRequisitions and QM.ListRequisitions(character) or {}
    local current = {}
    for _, record in ipairs(requisitions) do
        if record.status == "open" then current[#current + 1] = record end
    end
    titleLabel:SetText("QUARTERMASTER | " .. tostring(character or "Unknown") .. " (" .. #current .. ")")
    emptyLabel:SetText(#current == 0 and "No outstanding requisitions." or "")
    local offset = 3
    for index, record in ipairs(current) do
        local note = noteAt(index)
        note:ClearAllPoints()
        note:SetPoint("TOPLEFT", canvas, "TOPLEFT", 0, -offset)
        note.heading:SetText(tostring(record.purpose or record.id))
        note.complete.requisitionID = record.id
        local materialCount = #(record.materials or {})
        for lineIndex, material in ipairs(record.materials or {}) do
            local line = lineAt(note, lineIndex)
            line.check.requisitionID = record.id
            line.check.lineID = material.lineID
            line.check:SetChecked(material.acquired == true)
            local name = (QM.ItemName and QM.ItemName(material.itemID, material.name)) or material.name or tostring(material.itemID)
            line.text:SetText(string.format("%s  x%d", name, material.requiredQuantity or 0))
            line.check:Show()
            line.text:Show()
        end
        for lineIndex = materialCount + 1, #note.lines do
            note.lines[lineIndex].check:Hide()
            note.lines[lineIndex].text:Hide()
        end
        local noteHeight = 44 + math.max(1, materialCount) * LINE_HEIGHT
        note:SetHeight(noteHeight)
        note:Show()
        offset = offset + noteHeight + NOTE_GAP
    end
    for index = #current + 1, #notes do notes[index]:Hide() end
    canvas:SetHeight(math.max(offset, 60))
end

function QM.ToggleHUD(forceVisible)
    local settings = hudSettings()
    if not settings then return false end
    if type(forceVisible) == "boolean" then settings.visible = forceVisible
    else settings.visible = not (settings.visible ~= false) end
    QM.RefreshHUD()
    return settings.visible ~= false
end

function QM.ResetHUDPosition()
    local settings = hudSettings()
    if not settings then return end
    settings.x, settings.y = nil, nil
    if not hud then createHUD() end
    setPosition()
end

local startup = CreateFrame("Frame")
startup:RegisterEvent("PLAYER_ENTERING_WORLD")
startup:SetScript("OnEvent", function()
    if QM.database then QM.RefreshHUD() end
end)
