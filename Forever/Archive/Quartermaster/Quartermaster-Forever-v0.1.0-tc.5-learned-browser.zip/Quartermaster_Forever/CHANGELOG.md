# Quartermaster Forever changelog

## 2026-11-05 — 0.1.0-tc.3 (development test)
- Source baseline: 0.1.0-tc.2 TOC fix, unmodified retained.
- Adjust scanner UI detection to C_TradeSkillUI.IsTradeSkillReady rather than assuming specific Blizzard frame globals.
- Guard linked/guild/NPC professions and data-source switching.
- Retry transient empty/unready profession data after trade-skill events.
- Add TRADE_SKILL_UPDATE and NEW_RECIPE_LEARNED scan triggers; invalidate pending scan on close.
- /qm scan prints a specific failure reason instead of implying the window is closed.
- Keep learned-only filter and persistent per-character catalog; no SavedVariables schema change.
- Static structure and syntax checks: see verification outside artifact. In-game execution NOT_TESTED.
- No release approval or promotion.

## 2026-11-05 — 0.1.0-tc.4 (PENDING test candidate)
- Baseline: 0.1.0-tc.3 (owner confirmed Forever recipe scanner functioning in-game).
- Add independent per-character HUD.lua for movable, scrollable requisition post-it notes; saved visibility and screen position.
- HUD lists only currently logged-in character’s open requisitions, with item names and required quantities.
- Allow owner-only manual Acquired checkboxes and Complete button; preserve independent requisitions and inventory data.
- Add /qm hud show|hide|toggle|reset; refresh HUD on requisition edits, craft success, and inventory refresh.
- No scanner, inventory adapter, or crafting event implementation changes.
- Static archive, TOC and Lua syntax: to be recorded after checks. WoW runtime: NOT_TESTED.
- No owner release or promotion approval.
