-- Requisitions are independent demands. Same-item requirements remain distinct records.
local QM = Quartermaster
local function validText(value) return type(value) == "string" and value:match("%S") ~= nil end
local function actorIsOwner(owner)
    local actor = QM.CharacterKey()
    return actor ~= nil and actor == owner
end
local function db()
    if QM.disabled or not QM.database then return nil end
    return QM.database
end
local function checkMaterialLines(lines)
    if type(lines) ~= "table" or #lines == 0 then return false end
    for _, line in ipairs(lines) do
        if type(line) ~= "table" or type(line.itemID) ~= "number" or line.itemID < 1 or line.itemID % 1 ~= 0 or
            type(line.requiredQuantity) ~= "number" or line.requiredQuantity < 1 or line.requiredQuantity % 1 ~= 0 then
            return false
        end
    end
    return true
end
local function issue(kind, owner, purpose, lines, recipe)
    local database = db()
    if not database then return false, "NOT_READY" end
    if not actorIsOwner(owner) then return false, "FORBIDDEN" end
    if not validText(purpose) or not checkMaterialLines(lines) then return false, "INVALID_INPUT" end
    local materials = {}
    for index, line in ipairs(lines) do
        materials[index] = {lineID = index, itemID = line.itemID, name = line.name or tostring(line.itemID),
                            requiredQuantity = line.requiredQuantity, acquired = false}
    end
    local identifier = "QM-" .. database.nextRequisitionSequence
    database.nextRequisitionSequence = database.nextRequisitionSequence + 1
    local timestamp = time and time() or 0
    local record = {id = identifier, ownerKey = owner, type = kind, purpose = purpose,
        createdAt = timestamp, updatedAt = timestamp, status = "open", materials = materials,
        recipe = recipe and QM.Copy(recipe) or nil}
    database.requisitions.byID[identifier] = record
    table.insert(database.requisitions.order, identifier)
    return true, identifier
end
function QM.CreateManual(purpose, lines)
    return issue("manual", QM.CharacterKey(), purpose, lines)
end
function QM.CreateRecipe(purpose, lines, recipe)
    if type(recipe) ~= "table" or not validText(recipe.name) or
        type(recipe.requestedCrafts) ~= "number" or recipe.requestedCrafts < 1 or recipe.requestedCrafts % 1 ~= 0 then
        return false, "INVALID_RECIPE"
    end
    local normalized = {name = recipe.name, profession = recipe.profession or "",
        requestedCrafts = recipe.requestedCrafts, completedCrafts = 0, outputItemID = recipe.outputItemID, crafterKey = recipe.crafterKey}
    return issue("recipe", QM.CharacterKey(), purpose, lines, normalized)
end
function QM.ListRequisitions(owner)
    local database = db()
    if not database then return {} end
    local result = {}
    for _, identifier in ipairs(database.requisitions.order) do
        local record = database.requisitions.byID[identifier]
        if record and (not owner or record.ownerKey == owner) then table.insert(result, QM.Copy(record)) end
    end
    return result
end
-- Destructive removal is explicit and permitted only to the requisition owner.
-- Keep the sequence monotonic: deleted IDs are never reused.
function QM.DeleteRequisition(identifier)
    local database = db()
    local record = database and database.requisitions.byID[identifier]
    if not record then return false, "NOT_FOUND" end
    if not actorIsOwner(record.ownerKey) then return false, "FORBIDDEN" end
    database.requisitions.byID[identifier] = nil
    for index, existingID in ipairs(database.requisitions.order) do
        if existingID == identifier then
            table.remove(database.requisitions.order, index)
            break
        end
    end
    return true
end
function QM.SetAcquired(identifier, lineID, acquired)
    local database = db()
    local record = database and database.requisitions.byID[identifier]
    if not record then return false, "NOT_FOUND" end
    if not actorIsOwner(record.ownerKey) then return false, "FORBIDDEN" end
    if record.status ~= "open" then return false, "CLOSED" end
    if type(acquired) ~= "boolean" then return false, "INVALID_INPUT" end
    for _, line in ipairs(record.materials) do
        if line.lineID == lineID then
            line.acquired = acquired
            record.updatedAt = time and time() or 0
            return true
        end
    end
    return false, "NOT_FOUND"
end
function QM.SetComplete(identifier, completed)
    local database = db()
    local record = database and database.requisitions.byID[identifier]
    if not record then return false, "NOT_FOUND" end
    if not actorIsOwner(record.ownerKey) then return false, "FORBIDDEN" end
    if type(completed) ~= "boolean" then return false, "INVALID_INPUT" end
    record.status = completed and "closed" or "open"
    record.closedAt = completed and (time and time() or 0) or nil
    record.updatedAt = time and time() or 0
    return true
end
-- Credit only a self-confirmed result to an open recipe owned by the active character.
-- The 0.2.1 schema has no recipient/crafter routing, so other owners are never auto-closed.
function QM.RecordCraftSuccess(itemID, itemName, quantity)
    local database = db()
    local owner = QM.CharacterKey()
    if not database or not owner or type(quantity) ~= "number" or quantity < 1 then return false, "INVALID_RESULT" end
    for _, identifier in ipairs(database.requisitions.order) do
        local record = database.requisitions.byID[identifier]
        if record and record.type == "recipe" and record.status == "open" and record.ownerKey == owner and record.recipe then
            local recipe = record.recipe
            local sameID = type(recipe.outputItemID) == "number" and recipe.outputItemID == itemID
            local sameName = type(itemName) == "string" and type(recipe.name) == "string" and itemName:lower() == recipe.name:lower()
            if sameID or sameName then
                local remaining = recipe.requestedCrafts - (recipe.completedCrafts or 0)
                if remaining > 0 then
                    local credited = math.min(remaining, quantity)
                    recipe.completedCrafts = (recipe.completedCrafts or 0) + credited
                    record.updatedAt = time and time() or 0
                    if recipe.completedCrafts >= recipe.requestedCrafts then
                        record.status = "closed"
                        record.closedAt = record.updatedAt
                    end
                    return true, identifier, credited
                end
            end
        end
    end
    return false, "NO_MATCHING_OWNED_RECIPE"
end

-- Requisitions retain their own demand. Possession does not imply acquisition approval.
function QM.GetDemand(itemID)
    local total = 0
    for _, record in ipairs(QM.ListRequisitions()) do
        if record.status == "open" then
            for _, material in ipairs(record.materials) do
                if material.itemID == itemID and not material.acquired then
                    total = total + material.requiredQuantity
                end
            end
        end
    end
    return total
end
function QM.GetShoppingList()
    local shopping = {}
    for _, record in ipairs(QM.ListRequisitions()) do
        if record.status == "open" then
            for _, material in ipairs(record.materials) do
                if not material.acquired then
                    local item = shopping[material.itemID] or {itemID=material.itemID, name=QM.ItemName(material.itemID, material.name), quantity=0}
                    item.quantity = item.quantity + material.requiredQuantity
                    shopping[material.itemID] = item
                end
            end
        end
    end
    return shopping
end
function QM.SetCraftCount(identifier, quantity)
    local database = db()
    local record = database and database.requisitions.byID[identifier]
    if not record then return false, "NOT_FOUND" end
    if not actorIsOwner(record.ownerKey) then return false, "FORBIDDEN" end
    if record.status ~= "open" or record.type ~= "recipe" then return false, "NOT_OPEN_RECIPE" end
    if type(quantity) ~= "number" or quantity % 1 ~= 0 or quantity < 0 or quantity > record.recipe.requestedCrafts then
        return false, "INVALID_QUANTITY"
    end
    record.recipe.completedCrafts = quantity
    record.updatedAt = time and time() or 0
    return true
end
