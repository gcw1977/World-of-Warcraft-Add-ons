# Quartermaster Forever 0.1.0-tc.5 — browser test candidate

Baseline: tc.4 mini-HUD (SHA256 7bbf7276c415de05d3cac72de9c20b1c24d47a9348912a2ad3991d8d7272453f).

Changes: new Browser.lua read-only learned-output picker, profession filter cycling, case-insensitive substring search, 7-row paged list, native item tooltip; UI.lua adds Browse button and carries selected output item ID directly into manual requisition creation. Clearing or editing item text invalidates the selected ID. Original tc.4 HUD, scanner, and requisition modules are byte-identical. Existing Plan recipe button and CLI remain unchanged.

Caveats: only scanned recipes with numeric outputItemID appear; stale scans remain displayed with a warning; no in-client acceptance testing performed. Recipe browsing selects output items for manual requisitions, not material planning. The existing Plan recipe path remains available for material requests.
