QUARTERMASTER FOREVER 0.1.0-tc.1 — UNTESTED TEST CANDIDATE
=========================================================
Client: Forever 1.60.1 static API reference / interface 16001 (live build NOT VERIFIED).
Install Quartermaster_Forever directory into Forever/Interface/AddOns/. DO NOT install in Classic.
Forever SavedVariables are separate: QuartermasterForeverDB. Does not import Classic data.

SCOPE: Observed inventory, independent material requisitions, learned-only profession recipe catalog,
craft quantity tracking, and manual recipient completion. No gathering stats, node data, or costs.

Commands:
/qm or /rf : UI.  /qm help
/qm catalog : observed known recipes by character
/qm catalog <partial recipe name> : browse learned-only recipes
/qm scan : manually scan the open profession window
/qm plan 3 | Exact Learned Recipe Name : generate material form from learned recipe
/qm plan 3 | Exact Learned Recipe Name | Character : disambiguate crafter
/qm shop : combined unacquired demand vs observed account inventory
/qm inventory : last-seen bag and bank snapshots
/qm new Purpose | 2589:10 : manual item requisition
/qm complete QM-1 : recipient acknowledges completion

Forever scan deliberately filters GetRecipeInfo(id).learned == true.
The external AltStable addon was consulted solely as a reference for the API approach;
no AltStable code is included. Optional/choice reagents fail closed (no auto plan).
Craft success observation is best-effort chat parsing; use manual completion if not credited.
A craft by another character must NOT auto-close the requester's requisition.
Known LIMITATIONS for owner field test:
- No successful live Forever runtime evidence; UI/frame, profession and bank API compatibility uncertain.
- Automatic scanning requires an open local profession window and viable API data.
- Recipe results for optional/multiple reagent choices intentionally cannot be planned automatically.
- Recipe plan requires exact name and may need explicit character selection.
- Receipt attribution is manual: possession alone doesn't identify a particular delivery.
- Catalog and requisitions do not claim that all planned features have passed client tests.
No GitHub publication or release promotion authorized.

TC.3 scanner fix: use IsTradeSkillReady instead of frame-name assumptions, reject linked/NPC professions, retry delayed list population; /qm scan now prints failure reason.
