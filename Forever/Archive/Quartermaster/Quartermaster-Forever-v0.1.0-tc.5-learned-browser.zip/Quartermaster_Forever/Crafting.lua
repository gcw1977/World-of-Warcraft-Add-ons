-- Forever TC: conservative chat-based craft evidence, pending live verification.
-- Do not credit attempts (UNIT_SPELLCAST_*), inventory changes, or ordinary loot.
local QM = Quartermaster
local frame = CreateFrame("Frame")
frame:RegisterEvent("CHAT_MSG_LOOT")
local function formatPattern(template)
    if type(template) ~= "string" then return nil end
    local escaped = template:gsub("([%(%)%.%%%+%-%*%?%[%]%^%$])", "%%%1")
    escaped = escaped:gsub("%%%%s", "(.+)"):gsub("%%%%d", "(%%d+)")
    return "^" .. escaped .. "$"
end
local patterns = {
    {template = LOOT_ITEM_CREATED_SELF, multiple = false},
    {template = LOOT_ITEM_CREATED_SELF_MULTIPLE, multiple = true}
}
local function decodeCreated(message)
    for _, spec in ipairs(patterns) do
        local pattern = formatPattern(spec.template)
        if pattern then
            local itemText, quantity
            if spec.multiple then itemText, quantity = message:match(pattern)
            else itemText = message:match(pattern); quantity = 1 end
            if itemText then
                local itemID = tonumber(itemText:match("item:(%d+)"))
                local name = itemText:match("%[([^%]]+)%]") or itemText
                if itemID or name then return itemID, name, tonumber(quantity) or 1 end
            end
        end
    end
end
frame:SetScript("OnEvent", function(_, event, message)
    if event ~= "CHAT_MSG_LOOT" or type(message) ~= "string" or not QM.database then return end
    local id, name, count = decodeCreated(message)
    if not name then return end
    local ok, requisition, credited = QM.RecordCraftSuccess(id, name, count)
    if ok then
        if QM.Say then QM.Say("Confirmed craft credited to " .. requisition .. " (" .. credited .. ")") end
        if QM.RefreshUI then QM.RefreshUI() end
    end
end)
