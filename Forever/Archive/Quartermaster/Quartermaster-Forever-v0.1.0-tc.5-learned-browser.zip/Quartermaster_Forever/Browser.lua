-- Read-only learned-output browser. It never writes to the catalog or creates requisitions.
local QM = Quartermaster
local panel, searchBox, filterButton, statusText, rows = nil, nil, nil, nil, {}
local matches, professions, professionIndex, page = {}, {"All professions"}, 1, 1
local selectionCallback
local function outputName(recipe)
    local id = tonumber(recipe.outputItemID)
    if not id or id < 1 then return nil end
    local cached = (C_Item and C_Item.GetItemInfo and C_Item.GetItemInfo(id)) or (GetItemInfo and GetItemInfo(id))
    if type(cached) == "string" and cached ~= "" then return cached end
    -- Recipe names are the only safe fallback when item information has not arrived.
    return recipe.name or ("Item #" .. id)
end
local function refresh()
    if not panel then return end
    matches, professions = {}, {"All professions"}
    local found = {}
    local needle = (searchBox:GetText() or ""):lower()
    local catalog = QM.database and QM.database.recipeCatalog
    for character, data in pairs(catalog and catalog.characters or {}) do
        for profession, record in pairs(data.professions or {}) do
            if not found[profession] then found[profession] = true; professions[#professions+1] = profession end
            for _, recipe in pairs(record.recipes or {}) do
                if recipe.source == "forever-learned" and type(recipe.outputItemID) == "number" then
                    local name = outputName(recipe)
                    if name and (needle == "" or name:lower():find(needle, 1, true)) then
                        matches[#matches+1] = {name=name, itemID=recipe.outputItemID, profession=profession,
                            character=character, lastScan=record.lastScan or 0}
                    end
                end
            end
        end
    end
    table.sort(professions, function(a,b) return a<b end)
    if professionIndex > #professions then professionIndex=1 end
    filterButton:SetText(professions[professionIndex])
    local filtered, seen = {}, {}
    for _, entry in ipairs(matches) do
        if professionIndex == 1 or entry.profession == professions[professionIndex] then
            local key = tostring(entry.itemID) .. "|" .. entry.profession
            if not seen[key] then filtered[#filtered+1]=entry; seen[key]=true end
        end
    end
    table.sort(filtered, function(a,b) if a.name==b.name then return a.profession<b.profession end return a.name<b.name end)
    matches=filtered
    local totalPages=math.max(1,math.ceil(#matches/7))
    page=math.min(page,totalPages)
    statusText:SetText(string.format("%d learned outputs  |  page %d/%d  |  cached scans may be old",#matches,page,totalPages))
    for index, control in ipairs(rows) do
        local entry=matches[(page-1)*7+index]
        control.entry=entry
        if entry then
            control:SetText(string.format("%s  (%s)",entry.name,entry.profession))
            control:Show()
        else control:Hide() end
    end
end
local function makeButton(parent, text, width, x, y, callback)
    local control=CreateFrame("Button",nil,parent,"UIPanelButtonTemplate")
    control:SetSize(width,24); control:SetPoint("TOPLEFT",parent,"TOPLEFT",x,y)
    control:SetText(text); control:SetScript("OnClick",callback)
    return control
end
function QM.OpenLearnedOutputBrowser(onSelect)
    selectionCallback=onSelect
    if not panel then
        panel=CreateFrame("Frame","QuartermasterOutputBrowser",UIParent,"BackdropTemplate")
        panel:SetSize(490,350); panel:SetPoint("CENTER",UIParent,"CENTER",0,30)
        panel:SetFrameStrata("FULLSCREEN_DIALOG")
        panel:SetBackdrop({bgFile="Interface\\DialogFrame\\UI-DialogBox-Background",edgeFile="Interface\\DialogFrame\\UI-DialogBox-Border",edgeSize=24,
            insets={left=8,right=8,top=8,bottom=8}})
        local heading=panel:CreateFontString(nil,"OVERLAY","GameFontNormal")
        heading:SetPoint("TOPLEFT",18,-18); heading:SetText("Learned recipe outputs — select an item")
        makeButton(panel,"X",24,448,-12,function() panel:Hide() end)
        searchBox=CreateFrame("EditBox",nil,panel,"InputBoxTemplate")
        searchBox:SetSize(244,24); searchBox:SetPoint("TOPLEFT",panel,"TOPLEFT",18,-49)
        searchBox:SetAutoFocus(false); searchBox:SetText("")
        searchBox:SetScript("OnEscapePressed",function(self) self:ClearFocus() end)
        searchBox:SetScript("OnTextChanged",function() page=1; refresh() end)
        filterButton=makeButton(panel,"All professions",185,282,-49,function()
            professionIndex=professionIndex % #professions + 1; page=1; refresh()
        end)
        for index=1,7 do
            local control=makeButton(panel,"",450,18,-80-(index-1)*30,function(self)
                local entry=self.entry
                if entry and type(selectionCallback)=="function" then
                    selectionCallback(entry.itemID,entry.name,entry.profession)
                    panel:Hide()
                end
            end)
            control:GetFontString():SetJustifyH("LEFT")
            control:SetScript("OnEnter",function(self)
                if self.entry and GameTooltip then
                    GameTooltip:SetOwner(self,"ANCHOR_RIGHT")
                    local id=self.entry.itemID
                    if GameTooltip.SetItemByID then GameTooltip:SetItemByID(id)
                    elseif GameTooltip.SetHyperlink then GameTooltip:SetHyperlink("item:"..id) end
                    GameTooltip:Show()
                    if C_Item and C_Item.RequestLoadItemDataByID then C_Item.RequestLoadItemDataByID(id) end
                end
            end)
            control:SetScript("OnLeave",function() if GameTooltip then GameTooltip:Hide() end end)
            rows[index]=control
        end
        makeButton(panel,"< Prev",90,18,-295,function() page=math.max(1,page-1); refresh() end)
        makeButton(panel,"Next >",90,114,-295,function() page=page+1; refresh() end)
        statusText=panel:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
        statusText:SetPoint("TOPLEFT",220,-301)
        panel:RegisterEvent("GET_ITEM_INFO_RECEIVED")
        panel:SetScript("OnEvent",function(self) if self:IsShown() then refresh() end end)
    end
    page=1; professionIndex=1; panel:Show(); refresh()
end
