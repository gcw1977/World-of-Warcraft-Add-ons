-- Forever imports operate through the learned-only account catalog.
local QM=Quartermaster
function QM.ImportSelectedRecipe(craftCount)
    return false, "USE_QM_PLAN_COUNT_RECIPE_NAME_FROM_LEARNED_CATALOG"
end
