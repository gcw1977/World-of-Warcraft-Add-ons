# Quartermaster Forever 0.1.0-tc.6 - HUD logistics and resizing

- Account-wide open requisition material summary, grouped by item, with owners, outstanding quantities, last-observed available stock, shortages, and unknown-bank marker.
- Keeps personal post-it checkboxes and completion controls owner-only.
- Bottom-right HUD resize grip; width/height persisted in existing SavedVariables; /qm hud reset resets dimensions and position.
- Scrollable summary and compact empty state.

Static checks only. User in-game testing required. Account stock is not reserved/allocated automatically and may include old snapshots.
