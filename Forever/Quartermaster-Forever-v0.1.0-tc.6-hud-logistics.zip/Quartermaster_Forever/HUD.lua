-- Quartermaster Forever: current-character requisition post-its.
-- Never infer "Acquired" from inventory: stock is not assigned to demand.
-- This UI edits only requests owned by the logged-in character.
local QM = Quartermaster
local hud, canvas, scrollFrame, emptyLabel, titleLabel
local notes = {}
local summaryLines = {}
local sectionTitle
local PANEL_WIDTH, PANEL_HEIGHT = 330, 310
local MIN_WIDTH, MIN_HEIGHT = 255, 150
local MAX_WIDTH, MAX_HEIGHT = 760, 850
local NOTE_WIDTH, LINE_HEIGHT = 285, 19
local NOTE_GAP = 9

local function makeButton(parent, caption, width, height, action)
    local control = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
    control:SetSize(width, height)
    control:SetText(caption)
    control:SetScript("OnClick", action)
    return control
end

local function textLabel(parent, template)
    local text = parent:CreateFontString(nil, "OVERLAY", template or "GameFontNormalSmall")
    text:SetJustifyH("LEFT")
    return text
end

local function hudSettings()
    if not QM.database then return nil end
    QM.database.settings = QM.database.settings or {}
    QM.database.settings.requisitionHUD = QM.database.settings.requisitionHUD or { visible = true }
    return QM.database.settings.requisitionHUD
end

local function savePosition(frame)
    local settings = hudSettings()
    if not settings then return end
    local centerX, centerY = frame:GetCenter()
    local parentWidth, parentHeight = UIParent:GetWidth(), UIParent:GetHeight()
    if centerX and centerY and parentWidth > 0 and parentHeight > 0 then
        settings.x = centerX - parentWidth / 2
        settings.y = centerY - parentHeight / 2
    end
end

local function setPosition()
    if not hud then return end
    local settings = hudSettings()
    hud:ClearAllPoints()
    if settings and type(settings.x) == "number" and type(settings.y) == "number" then
        hud:SetPoint("CENTER", UIParent, "CENTER", settings.x, settings.y)
    else
        hud:SetPoint("RIGHT", UIParent, "RIGHT", -35, 30)
    end
end

local function createHUD()
    hud = CreateFrame("Frame", "QuartermasterRequisitionHUD", UIParent, "BackdropTemplate")
    local settings = hudSettings()
    hud:SetSize(math.max(MIN_WIDTH, math.min(MAX_WIDTH, tonumber(settings and settings.width) or PANEL_WIDTH)),
                math.max(MIN_HEIGHT, math.min(MAX_HEIGHT, tonumber(settings and settings.height) or PANEL_HEIGHT)))
    hud:SetResizable(true)
    if hud.SetResizeBounds then hud:SetResizeBounds(MIN_WIDTH, MIN_HEIGHT, MAX_WIDTH, MAX_HEIGHT)
    elseif hud.SetMinResize then hud:SetMinResize(MIN_WIDTH, MIN_HEIGHT); hud:SetMaxResize(MAX_WIDTH, MAX_HEIGHT) end
    hud:SetFrameStrata("MEDIUM")
    hud:SetClampedToScreen(true)
    hud:SetMovable(true)
    hud:EnableMouse(true)
    hud:RegisterForDrag("LeftButton")
    hud:SetScript("OnDragStart", hud.StartMoving)
    hud:SetScript("OnDragStop", function(self) self:StopMovingOrSizing(); savePosition(self) end)
    hud:SetBackdrop({bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
        edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", edgeSize = 14,
        insets = {left = 4, right = 4, top = 4, bottom = 4}})
    titleLabel = textLabel(hud, "GameFontNormal")
    titleLabel:SetPoint("TOPLEFT", hud, "TOPLEFT", 13, -13)
    titleLabel:SetText("QUARTERMASTER  |  REQUISITIONS")
    local closeButton = makeButton(hud, "X", 25, 22, function()
        local settings = hudSettings()
        if settings then settings.visible = false end
        hud:Hide()
    end)
    closeButton:SetPoint("TOPRIGHT", hud, "TOPRIGHT", -8, -8)
    scrollFrame = CreateFrame("ScrollFrame", "QuartermasterRequisitionHUDScroll", hud, "UIPanelScrollFrameTemplate")
    scrollFrame:SetPoint("TOPLEFT", hud, "TOPLEFT", 9, -44)
    scrollFrame:SetPoint("BOTTOMRIGHT", hud, "BOTTOMRIGHT", -31, 24)
    canvas = CreateFrame("Frame", nil, scrollFrame)
    canvas:SetWidth(math.max(200, hud:GetWidth() - 48))
    canvas:SetHeight(1)
    scrollFrame:SetScrollChild(canvas)
    emptyLabel = textLabel(canvas, "GameFontHighlightSmall")
    emptyLabel:SetPoint("TOPLEFT", canvas, "TOPLEFT", 10, -16)
    emptyLabel:SetWidth(math.max(160, hud:GetWidth() - 68))
    local grip = CreateFrame("Button", nil, hud)
    grip:SetSize(19, 19)
    grip:SetPoint("BOTTOMRIGHT", hud, "BOTTOMRIGHT", -5, 4)
    local gripTexture = grip:CreateTexture(nil, "OVERLAY")
    gripTexture:SetAllPoints()
    gripTexture:SetTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Up")
    grip:SetNormalTexture(gripTexture)
    grip:SetScript("OnMouseDown", function(_, button)
        if button == "LeftButton" then hud:StartSizing("BOTTOMRIGHT") end
    end)
    grip:SetScript("OnMouseUp", function(_, button)
        if button == "LeftButton" then
            hud:StopMovingOrSizing()
            local cfg = hudSettings()
            if cfg then cfg.width, cfg.height = hud:GetWidth(), hud:GetHeight() end
            if QM.RefreshHUD then QM.RefreshHUD() end
        end
    end)
    hud:SetScript("OnSizeChanged", function(self)
        if not canvas then return end
        local width = math.max(200, self:GetWidth() - 48)
        canvas:SetWidth(width)
        emptyLabel:SetWidth(math.max(160, width - 20))
        if QM.RefreshHUD and self:IsShown() then QM.RefreshHUD() end
    end)
    sectionTitle = textLabel(canvas, "GameFontNormalSmall")
    sectionTitle:SetText("ACCOUNT MATERIAL REQUIREMENTS")
    sectionTitle:SetTextColor(1, 0.82, 0.2)
    setPosition()
    hud:Hide()
end

local function noteAt(index)
    if notes[index] then return notes[index] end
    local note = CreateFrame("Frame", nil, canvas, "BackdropTemplate")
    note:SetWidth(math.max(190, canvas:GetWidth() - 8))
    note:SetBackdrop({bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", edgeSize = 10,
        insets = {left = 3, right = 3, top = 3, bottom = 3}})
    note:SetBackdropColor(0.22, 0.19, 0.08, 0.95)
    note:SetBackdropBorderColor(0.65, 0.55, 0.28, 0.85)
    note.heading = textLabel(note, "GameFontNormal")
    note.heading:SetPoint("TOPLEFT", note, "TOPLEFT", 9, -9)
    note.heading:SetWidth(math.max(85, canvas:GetWidth() - 102))
    note.complete = makeButton(note, "Done", 65, 21, function(self)
        if QM.SetComplete and self.requisitionID then
            local ok, reason = QM.SetComplete(self.requisitionID, true)
            if not ok and QM.Say then QM.Say("Could not complete: " .. tostring(reason)) end
            if QM.RefreshUI then QM.RefreshUI() end
        end
    end)
    note.complete:SetPoint("TOPRIGHT", note, "TOPRIGHT", -7, -5)
    note.lines = {}
    notes[index] = note
    return note
end

local function lineAt(note, index)
    if note.lines[index] then return note.lines[index] end
    local line = {}
    line.check = CreateFrame("CheckButton", nil, note, "UICheckButtonTemplate")
    line.check:SetSize(21, 21)
    line.check:SetPoint("TOPLEFT", note, "TOPLEFT", 6, -35 - (index - 1) * LINE_HEIGHT)
    line.text = textLabel(note, "GameFontHighlightSmall")
    line.text:SetPoint("LEFT", line.check, "RIGHT", 1, 0)
    line.text:SetWidth(math.max(120, canvas:GetWidth() - 54))
    line.check:SetScript("OnClick", function(self)
        local ok, reason = QM.SetAcquired(self.requisitionID, self.lineID, self:GetChecked() == true)
        if not ok and QM.Say then QM.Say("Could not update item: " .. tostring(reason)) end
        if QM.RefreshUI then QM.RefreshUI() end
    end)
    note.lines[index] = line
    return line
end

-- Rebuild presentation from saved requisitions; no independent HUD demand cache.
function QM.RefreshHUD()
    if not QM.database or QM.disabled then return end
    if not hud then createHUD() end
    local settings = hudSettings()
    if not settings or settings.visible == false then hud:Hide(); return end
    hud:Show()
    local character = QM.CharacterKey()
    local requisitions = QM.ListRequisitions and QM.ListRequisitions(character) or {}
    local current = {}
    for _, record in ipairs(requisitions) do
        if record.status == "open" then current[#current + 1] = record end
    end
    titleLabel:SetText("QUARTERMASTER | " .. tostring(character or "Unknown") .. " (" .. #current .. ")")
    emptyLabel:SetText(#current == 0 and "No personal requisitions." or "")
    local availableWidth = math.max(200, canvas:GetWidth() - 8)
    local offset = (#current == 0) and 43 or 3
    for index, record in ipairs(current) do
        local note = noteAt(index)
        note:ClearAllPoints()
        note:SetWidth(availableWidth)
        note.heading:SetWidth(math.max(85, availableWidth - 94))
        note:SetPoint("TOPLEFT", canvas, "TOPLEFT", 0, -offset)
        note.heading:SetText(tostring(record.purpose or record.id))
        note.complete.requisitionID = record.id
        local materialCount = #(record.materials or {})
        for lineIndex, material in ipairs(record.materials or {}) do
            local line = lineAt(note, lineIndex)
            line.check.requisitionID = record.id
            line.check.lineID = material.lineID
            line.check:SetChecked(material.acquired == true)
            local name = (QM.ItemName and QM.ItemName(material.itemID, material.name)) or material.name or tostring(material.itemID)
            line.text:SetWidth(math.max(120, availableWidth - 41))
            line.text:SetText(string.format("%s  x%d", name, material.requiredQuantity or 0))
            line.check:Show()
            line.text:Show()
        end
        for lineIndex = materialCount + 1, #note.lines do
            note.lines[lineIndex].check:Hide()
            note.lines[lineIndex].text:Hide()
        end
        local noteHeight = 44 + math.max(1, materialCount) * LINE_HEIGHT
        note:SetHeight(noteHeight)
        note:Show()
        offset = offset + noteHeight + NOTE_GAP
    end
    for index = #current + 1, #notes do notes[index]:Hide() end
    -- Read-only logistics; never reassign or auto-mark another character's demand.
    local grouped, ordered = {}, {}
    for _, requisition in ipairs(QM.ListRequisitions and QM.ListRequisitions() or {}) do
        if requisition.status == "open" then
            for _, material in ipairs(requisition.materials or {}) do
                if not material.acquired and material.itemID then
                    local key = tostring(material.itemID)
                    local entry = grouped[key]
                    if not entry then
                        entry = {itemID=material.itemID, name=material.name, quantity=0, owners={}}
                        grouped[key] = entry
                        table.insert(ordered, entry)
                    end
                    local count = tonumber(material.requiredQuantity) or 0
                    entry.quantity = entry.quantity + count
                    local owner = tostring(requisition.ownerKey or "Unknown")
                    entry.owners[owner] = (entry.owners[owner] or 0) + count
                end
            end
        end
    end
    table.sort(ordered, function(a, b)
        return tostring(QM.ItemName and QM.ItemName(a.itemID, a.name) or a.name or a.itemID):lower()
             < tostring(QM.ItemName and QM.ItemName(b.itemID, b.name) or b.name or b.itemID):lower()
    end)
    offset = offset + 9
    sectionTitle:ClearAllPoints()
    sectionTitle:SetPoint("TOPLEFT", canvas, "TOPLEFT", 8, -offset)
    sectionTitle:SetWidth(availableWidth - 8)
    offset = offset + 23
    for index, entry in ipairs(ordered) do
        local line = summaryLines[index]
        if not line then
            line = textLabel(canvas, "GameFontHighlightSmall")
            line:SetJustifyH("LEFT")
            summaryLines[index] = line
        end
        local name = (QM.ItemName and QM.ItemName(entry.itemID, entry.name)) or entry.name or tostring(entry.itemID)
        local stock, unknownBanks = 0, 0
        if QM.CountAcrossCharacters then stock, unknownBanks = QM.CountAcrossCharacters(entry.itemID) end
        stock = tonumber(stock) or 0
        unknownBanks = tonumber(unknownBanks) or 0
        local shortage = math.max(0, entry.quantity - stock)
        local owners = {}
        for owner, count in pairs(entry.owners) do table.insert(owners, owner .. " " .. count) end
        table.sort(owners)
        local unknownNote = unknownBanks > 0 and " (+unknown banks)" or ""
        line:SetText(string.format("%s: need %d | stock %d | short %d%s\n  %s", name, entry.quantity, stock, shortage, unknownNote, table.concat(owners, ", ")))
        line:SetWidth(availableWidth - 14)
        line:ClearAllPoints()
        line:SetPoint("TOPLEFT", canvas, "TOPLEFT", 9, -offset)
        line:Show()
        offset = offset + 35
    end
    for index = #ordered + 1, #summaryLines do summaryLines[index]:Hide() end
    if #ordered == 0 then
        local line = summaryLines[1] or textLabel(canvas, "GameFontHighlightSmall")
        summaryLines[1] = line
        line:SetText("No outstanding account-wide material needs.")
        line:SetWidth(availableWidth - 14)
        line:ClearAllPoints()
        line:SetPoint("TOPLEFT", canvas, "TOPLEFT", 9, -offset)
        line:Show()
        offset = offset + 25
    end
    canvas:SetHeight(math.max(offset + 8, 60))
end

function QM.ToggleHUD(forceVisible)
    local settings = hudSettings()
    if not settings then return false end
    if type(forceVisible) == "boolean" then settings.visible = forceVisible
    else settings.visible = not (settings.visible ~= false) end
    QM.RefreshHUD()
    return settings.visible ~= false
end

function QM.ResetHUDPosition()
    local settings = hudSettings()
    if not settings then return end
    settings.x, settings.y, settings.width, settings.height = nil, nil, nil, nil
    if hud then hud:SetSize(PANEL_WIDTH, PANEL_HEIGHT) end
    if not hud then createHUD() end
    setPosition()
end

local startup = CreateFrame("Frame")
startup:RegisterEvent("PLAYER_ENTERING_WORLD")
startup:SetScript("OnEvent", function()
    if QM.database then QM.RefreshHUD() end
end)
